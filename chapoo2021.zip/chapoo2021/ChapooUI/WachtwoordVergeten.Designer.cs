﻿
namespace ChapooUI
{
    partial class WachtwoordVergeten
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(WachtwoordVergeten));
            this.btn_Ucheck = new System.Windows.Forms.Button();
            this.lbl_question = new System.Windows.Forms.Label();
            this.btn_back = new System.Windows.Forms.Button();
            this.btn_check = new System.Windows.Forms.Button();
            this.txt_repeatpass = new System.Windows.Forms.TextBox();
            this.txt_newpass = new System.Windows.Forms.TextBox();
            this.txt_answer = new System.Windows.Forms.TextBox();
            this.txt_User = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Ucheck
            // 
            this.btn_Ucheck.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.btn_Ucheck.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_Ucheck.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_Ucheck.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_Ucheck.ForeColor = System.Drawing.Color.White;
            this.btn_Ucheck.Location = new System.Drawing.Point(624, 36);
            this.btn_Ucheck.Name = "btn_Ucheck";
            this.btn_Ucheck.Size = new System.Drawing.Size(113, 50);
            this.btn_Ucheck.TabIndex = 25;
            this.btn_Ucheck.Text = "Check";
            this.btn_Ucheck.UseVisualStyleBackColor = false;
            // 
            // lbl_question
            // 
            this.lbl_question.AutoSize = true;
            this.lbl_question.Font = new System.Drawing.Font("Segoe UI", 17.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_question.ForeColor = System.Drawing.Color.White;
            this.lbl_question.Location = new System.Drawing.Point(-85, 10);
            this.lbl_question.Name = "lbl_question";
            this.lbl_question.Size = new System.Drawing.Size(0, 31);
            this.lbl_question.TabIndex = 24;
            // 
            // btn_back
            // 
            this.btn_back.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(0)))), ((int)(((byte)(14)))));
            this.btn_back.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_back.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_back.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_back.ForeColor = System.Drawing.Color.White;
            this.btn_back.Location = new System.Drawing.Point(278, 348);
            this.btn_back.Name = "btn_back";
            this.btn_back.Size = new System.Drawing.Size(152, 49);
            this.btn_back.TabIndex = 23;
            this.btn_back.Text = "Back";
            this.btn_back.UseVisualStyleBackColor = false;
            this.btn_back.Click += new System.EventHandler(this.btn_back_Click_1);
            // 
            // btn_check
            // 
            this.btn_check.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.btn_check.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.btn_check.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btn_check.Font = new System.Drawing.Font("Segoe UI", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_check.ForeColor = System.Drawing.Color.White;
            this.btn_check.Location = new System.Drawing.Point(466, 348);
            this.btn_check.Name = "btn_check";
            this.btn_check.Size = new System.Drawing.Size(152, 49);
            this.btn_check.TabIndex = 22;
            this.btn_check.Text = "Change";
            this.btn_check.UseVisualStyleBackColor = false;
            // 
            // txt_repeatpass
            // 
            this.txt_repeatpass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.txt_repeatpass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_repeatpass.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_repeatpass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.txt_repeatpass.Location = new System.Drawing.Point(278, 283);
            this.txt_repeatpass.Name = "txt_repeatpass";
            this.txt_repeatpass.Size = new System.Drawing.Size(340, 50);
            this.txt_repeatpass.TabIndex = 21;
            this.txt_repeatpass.Text = "Herhaal Wachtwoord";
            this.txt_repeatpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_newpass
            // 
            this.txt_newpass.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.txt_newpass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_newpass.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_newpass.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.txt_newpass.Location = new System.Drawing.Point(278, 207);
            this.txt_newpass.Name = "txt_newpass";
            this.txt_newpass.Size = new System.Drawing.Size(340, 50);
            this.txt_newpass.TabIndex = 20;
            this.txt_newpass.Text = "Nieuw Wachtwoord";
            this.txt_newpass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_answer
            // 
            this.txt_answer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.txt_answer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_answer.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_answer.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.txt_answer.Location = new System.Drawing.Point(278, 135);
            this.txt_answer.Name = "txt_answer";
            this.txt_answer.Size = new System.Drawing.Size(340, 50);
            this.txt_answer.TabIndex = 19;
            this.txt_answer.Text = "Antwoord";
            this.txt_answer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_User
            // 
            this.txt_User.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.txt_User.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_User.Font = new System.Drawing.Font("Segoe UI", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_User.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(112)))), ((int)(((byte)(112)))), ((int)(((byte)(112)))));
            this.txt_User.Location = new System.Drawing.Point(278, 36);
            this.txt_User.Name = "txt_User";
            this.txt_User.Size = new System.Drawing.Size(340, 50);
            this.txt_User.TabIndex = 18;
            this.txt_User.Text = "Username";
            this.txt_User.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.panel1.Location = new System.Drawing.Point(262, 36);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(2, 353);
            this.panel1.TabIndex = 17;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.InitialImage = null;
            this.pictureBox1.Location = new System.Drawing.Point(13, 20);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(234, 115);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 16;
            this.pictureBox1.TabStop = false;
            // 
            // WachtwoordVergeten
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(46)))), ((int)(((byte)(63)))));
            this.ClientSize = new System.Drawing.Size(756, 456);
            this.Controls.Add(this.btn_Ucheck);
            this.Controls.Add(this.lbl_question);
            this.Controls.Add(this.btn_back);
            this.Controls.Add(this.btn_check);
            this.Controls.Add(this.txt_repeatpass);
            this.Controls.Add(this.txt_newpass);
            this.Controls.Add(this.txt_answer);
            this.Controls.Add(this.txt_User);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.pictureBox1);
            this.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.Name = "WachtwoordVergeten";
            this.Text = "WachtwoordVergeten";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Ucheck;
        private System.Windows.Forms.Label lbl_question;
        private System.Windows.Forms.Button btn_back;
        private System.Windows.Forms.Button btn_check;
        private System.Windows.Forms.TextBox txt_repeatpass;
        private System.Windows.Forms.TextBox txt_newpass;
        private System.Windows.Forms.TextBox txt_answer;
        private System.Windows.Forms.TextBox txt_User;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}