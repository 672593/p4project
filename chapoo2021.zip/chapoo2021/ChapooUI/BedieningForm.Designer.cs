﻿
namespace ChapooUI
{
    partial class BedieningForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Chapoo_title = new System.Windows.Forms.Label();
            this.LogOffLink = new System.Windows.Forms.Label();
            this.Table6_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_6 = new System.Windows.Forms.Label();
            this.lbl_w_6 = new System.Windows.Forms.Label();
            this.PayBtn6 = new System.Windows.Forms.Button();
            this.ReservationBtn6 = new System.Windows.Forms.Button();
            this.OrderBtn6 = new System.Windows.Forms.Button();
            this.Table6_Title = new System.Windows.Forms.Label();
            this.Table7_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_7 = new System.Windows.Forms.Label();
            this.lbl_w_7 = new System.Windows.Forms.Label();
            this.PayBtn7 = new System.Windows.Forms.Button();
            this.ReservationBtn7 = new System.Windows.Forms.Button();
            this.OrderBtn7 = new System.Windows.Forms.Button();
            this.Table7_Title = new System.Windows.Forms.Label();
            this.Table2_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_2 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.lbl_w_2 = new System.Windows.Forms.Label();
            this.PayBtn2 = new System.Windows.Forms.Button();
            this.ReservationBtn2 = new System.Windows.Forms.Button();
            this.OrderBtn2 = new System.Windows.Forms.Button();
            this.Table2_Title = new System.Windows.Forms.Label();
            this.Table8_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_8 = new System.Windows.Forms.Label();
            this.lbl_w_8 = new System.Windows.Forms.Label();
            this.PayBtn8 = new System.Windows.Forms.Button();
            this.Reser8vationBtn = new System.Windows.Forms.Button();
            this.OrderBtn8 = new System.Windows.Forms.Button();
            this.Table8_Title = new System.Windows.Forms.Label();
            this.Table3_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_3 = new System.Windows.Forms.Label();
            this.lbl_w_3 = new System.Windows.Forms.Label();
            this.PayBtn3 = new System.Windows.Forms.Button();
            this.ReservationBtn3 = new System.Windows.Forms.Button();
            this.OrderBtn3 = new System.Windows.Forms.Button();
            this.Table3_Title = new System.Windows.Forms.Label();
            this.Table9_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_9 = new System.Windows.Forms.Label();
            this.lbl_w_9 = new System.Windows.Forms.Label();
            this.PayBtn9 = new System.Windows.Forms.Button();
            this.ReservationBtn9 = new System.Windows.Forms.Button();
            this.OrderBtn9 = new System.Windows.Forms.Button();
            this.Table9_Title = new System.Windows.Forms.Label();
            this.Table4_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_4 = new System.Windows.Forms.Label();
            this.lbl_w_4 = new System.Windows.Forms.Label();
            this.PayBtn4 = new System.Windows.Forms.Button();
            this.ResservationBtn4 = new System.Windows.Forms.Button();
            this.OrderBtn4 = new System.Windows.Forms.Button();
            this.Table4_tiitle = new System.Windows.Forms.Label();
            this.Table10_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_10 = new System.Windows.Forms.Label();
            this.lbl_w_10 = new System.Windows.Forms.Label();
            this.PayBtn10 = new System.Windows.Forms.Button();
            this.ReservationBtn10 = new System.Windows.Forms.Button();
            this.OrderBtn10 = new System.Windows.Forms.Button();
            this.Table10_Title = new System.Windows.Forms.Label();
            this.Table5_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_5 = new System.Windows.Forms.Label();
            this.lbl_w_5 = new System.Windows.Forms.Label();
            this.PayBtn5 = new System.Windows.Forms.Button();
            this.ReservationBtn5 = new System.Windows.Forms.Button();
            this.OrderBtn5 = new System.Windows.Forms.Button();
            this.Table5_Title = new System.Windows.Forms.Label();
            this.AllOrdersBtn = new System.Windows.Forms.Button();
            this.AllreservationsBtn = new System.Windows.Forms.Button();
            this.Order_pnl = new System.Windows.Forms.Panel();
            this.AllOrders_pnl = new System.Windows.Forms.Panel();
            this.ChooseTableDD = new System.Windows.Forms.ComboBox();
            this.ChooseTablelbl = new System.Windows.Forms.Label();
            this.ChangeBtn = new System.Windows.Forms.Button();
            this.DeleteOrderBtn = new System.Windows.Forms.Button();
            this.DeleteOrderItemBtn = new System.Windows.Forms.Button();
            this.AllOrderslv = new System.Windows.Forms.ListView();
            this.order_id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.orderTableId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.itemName_ = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.aantal1 = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.orderItemStatus_ = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.ChangeRes_pnl = new System.Windows.Forms.Panel();
            this.TafelResDD = new System.Windows.Forms.TextBox();
            this.aamBox = new System.Windows.Forms.TextBox();
            this.naamLbl = new System.Windows.Forms.Label();
            this.ChangeResAcceptBtn = new System.Windows.Forms.Button();
            this.aantekeningBox = new System.Windows.Forms.TextBox();
            this.aantekeninglbl = new System.Windows.Forms.Label();
            this.datumBox = new System.Windows.Forms.TextBox();
            this.emailBox = new System.Windows.Forms.TextBox();
            this.telBox = new System.Windows.Forms.TextBox();
            this.datumLbl = new System.Windows.Forms.Label();
            this.emailLbl = new System.Windows.Forms.Label();
            this.telnrLbl = new System.Windows.Forms.Label();
            this.ResTafellbl = new System.Windows.Forms.Label();
            this.Res_pnl = new System.Windows.Forms.Panel();
            this.ChangeResBtn = new System.Windows.Forms.Button();
            this.DeleteResBtn = new System.Windows.Forms.Button();
            this.Reservationlv = new System.Windows.Forms.ListView();
            this.reservationId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tableId = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.reservationName = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.reservationTel = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.reservationEmail = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.reservationComment = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.reservationDate = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.AddRes_pnl = new System.Windows.Forms.Panel();
            this.AddNaamDD = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.BevestigResBtn = new System.Windows.Forms.Button();
            this.AddOpmerking = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.AddDatum = new System.Windows.Forms.TextBox();
            this.AddEmail = new System.Windows.Forms.TextBox();
            this.Addtel = new System.Windows.Forms.TextBox();
            this.AddTafelDD = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.AddResBtn = new System.Windows.Forms.Button();
            this.AllResBtn = new System.Windows.Forms.Button();
            this.AddOrder_pnl = new System.Windows.Forms.Panel();
            this.orderslv = new System.Windows.Forms.ListView();
            this.gerecht = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.aantal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.consumptieLabel = new System.Windows.Forms.Label();
            this.ConsumptieDD = new System.Windows.Forms.ComboBox();
            this.minBtn = new System.Windows.Forms.Button();
            this.plusBtn = new System.Windows.Forms.Button();
            this.OrderAddBtn = new System.Windows.Forms.Button();
            this.opmerkingBox = new System.Windows.Forms.TextBox();
            this.opmerkinglbl = new System.Windows.Forms.Label();
            this.amountOrderItem = new System.Windows.Forms.TextBox();
            this.aantalllbl = new System.Windows.Forms.Label();
            this.Consumptielbl = new System.Windows.Forms.Label();
            this.MenuDD = new System.Windows.Forms.ComboBox();
            this.Menulbl = new System.Windows.Forms.Label();
            this.TafelDD = new System.Windows.Forms.ComboBox();
            this.tafellbl = new System.Windows.Forms.Label();
            this.BackToTablesBtn = new System.Windows.Forms.Button();
            this.ChangeAmount_pnl = new System.Windows.Forms.Panel();
            this.plusAantalBtn = new System.Windows.Forms.Button();
            this.minAantalBtn = new System.Windows.Forms.Button();
            this.ChangeAcceptBtn = new System.Windows.Forms.Button();
            this.AmountBox = new System.Windows.Forms.TextBox();
            this.Aantallbl = new System.Windows.Forms.Label();
            this.orderItemlbl = new System.Windows.Forms.Label();
            this.orderIDlbl = new System.Windows.Forms.Label();
            this.AllOrdersBtn2 = new System.Windows.Forms.Button();
            this.AddBtn = new System.Windows.Forms.Button();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Table1_Title = new System.Windows.Forms.Label();
            this.OrderBtn1 = new System.Windows.Forms.Button();
            this.ReservationBtn1 = new System.Windows.Forms.Button();
            this.PayBtn1 = new System.Windows.Forms.Button();
            this.Table1_pnl = new System.Windows.Forms.Panel();
            this.lbl_tf_1 = new System.Windows.Forms.Label();
            this.lbl_w_1 = new System.Windows.Forms.Label();
            this.pnl_Afrekenen = new System.Windows.Forms.Panel();
            this.txtbox_betaaldBedrag = new System.Windows.Forms.TextBox();
            this.lbl_betaaldBedrag = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbBox_betaalmethode = new System.Windows.Forms.ComboBox();
            this.listview_productenAfrekenen = new System.Windows.Forms.ListView();
            this.AfrekenID = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AfrekenProduct = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.AfrekenAantal = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lbl_afrekenen = new System.Windows.Forms.Button();
            this.txtbox_fooiBedrag = new System.Windows.Forms.TextBox();
            this.lbl_orderIDAfrekenen = new System.Windows.Forms.Label();
            this.lbl_AfrekenTafel = new System.Windows.Forms.Label();
            this.lbl_fooi = new System.Windows.Forms.Label();
            this.lbl_btw = new System.Windows.Forms.Label();
            this.lbl_overzichtBedrag = new System.Windows.Forms.Label();
            this.lbl_totaalOverzicht = new System.Windows.Forms.Label();
            this.lbl_btwBedrag = new System.Windows.Forms.Label();
            this.btn_terugTafels = new System.Windows.Forms.Button();
            this.Table6_pnl.SuspendLayout();
            this.Table7_pnl.SuspendLayout();
            this.Table2_pnl.SuspendLayout();
            this.Table8_pnl.SuspendLayout();
            this.Table3_pnl.SuspendLayout();
            this.Table9_pnl.SuspendLayout();
            this.Table4_pnl.SuspendLayout();
            this.Table10_pnl.SuspendLayout();
            this.Table5_pnl.SuspendLayout();
            this.Order_pnl.SuspendLayout();
            this.AllOrders_pnl.SuspendLayout();
            this.ChangeRes_pnl.SuspendLayout();
            this.Res_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.AddRes_pnl.SuspendLayout();
            this.AddOrder_pnl.SuspendLayout();
            this.ChangeAmount_pnl.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.Table1_pnl.SuspendLayout();
            this.pnl_Afrekenen.SuspendLayout();
            this.SuspendLayout();
            // 
            // Chapoo_title
            // 
            this.Chapoo_title.AutoSize = true;
            this.Chapoo_title.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Chapoo_title.ForeColor = System.Drawing.Color.White;
            this.Chapoo_title.Location = new System.Drawing.Point(106, 18);
            this.Chapoo_title.Name = "Chapoo_title";
            this.Chapoo_title.Size = new System.Drawing.Size(116, 21);
            this.Chapoo_title.TabIndex = 0;
            this.Chapoo_title.Text = "| Tafeloverzicht ";
            // 
            // LogOffLink
            // 
            this.LogOffLink.AutoSize = true;
            this.LogOffLink.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LogOffLink.ForeColor = System.Drawing.Color.Red;
            this.LogOffLink.Location = new System.Drawing.Point(1333, 24);
            this.LogOffLink.Name = "LogOffLink";
            this.LogOffLink.Size = new System.Drawing.Size(86, 15);
            this.LogOffLink.TabIndex = 11;
            this.LogOffLink.Text = "UITLOGGEN";
            // 
            // Table6_pnl
            // 
            this.Table6_pnl.Controls.Add(this.lbl_tf_6);
            this.Table6_pnl.Controls.Add(this.lbl_w_6);
            this.Table6_pnl.Controls.Add(this.PayBtn6);
            this.Table6_pnl.Controls.Add(this.ReservationBtn6);
            this.Table6_pnl.Controls.Add(this.OrderBtn6);
            this.Table6_pnl.Controls.Add(this.Table6_Title);
            this.Table6_pnl.Location = new System.Drawing.Point(13, 304);
            this.Table6_pnl.Name = "Table6_pnl";
            this.Table6_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table6_pnl.TabIndex = 18;
            // 
            // lbl_tf_6
            // 
            this.lbl_tf_6.AutoSize = true;
            this.lbl_tf_6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_6.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_6.Location = new System.Drawing.Point(104, 14);
            this.lbl_tf_6.Name = "lbl_tf_6";
            this.lbl_tf_6.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_6.TabIndex = 53;
            this.lbl_tf_6.Text = "asdsad";
            // 
            // lbl_w_6
            // 
            this.lbl_w_6.AutoSize = true;
            this.lbl_w_6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_6.ForeColor = System.Drawing.Color.White;
            this.lbl_w_6.Location = new System.Drawing.Point(28, 178);
            this.lbl_w_6.Name = "lbl_w_6";
            this.lbl_w_6.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_6.TabIndex = 52;
            this.lbl_w_6.Text = "Geen lopende order";
            // 
            // PayBtn6
            // 
            this.PayBtn6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn6.ForeColor = System.Drawing.Color.White;
            this.PayBtn6.Location = new System.Drawing.Point(27, 139);
            this.PayBtn6.Name = "PayBtn6";
            this.PayBtn6.Size = new System.Drawing.Size(216, 38);
            this.PayBtn6.TabIndex = 17;
            this.PayBtn6.Text = "AFREKENEN";
            this.PayBtn6.UseVisualStyleBackColor = false;
            this.PayBtn6.Click += new System.EventHandler(this.PayBtn6_Click);
            // 
            // ReservationBtn6
            // 
            this.ReservationBtn6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationBtn6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ReservationBtn6.ForeColor = System.Drawing.Color.White;
            this.ReservationBtn6.Location = new System.Drawing.Point(27, 95);
            this.ReservationBtn6.Name = "ReservationBtn6";
            this.ReservationBtn6.Size = new System.Drawing.Size(216, 38);
            this.ReservationBtn6.TabIndex = 16;
            this.ReservationBtn6.Text = "RESERVATIE";
            this.ReservationBtn6.UseVisualStyleBackColor = false;
            this.ReservationBtn6.Click += new System.EventHandler(this.ReservationBtn6_Click);
            // 
            // OrderBtn6
            // 
            this.OrderBtn6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn6.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn6.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn6.ForeColor = System.Drawing.Color.White;
            this.OrderBtn6.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn6.Name = "OrderBtn6";
            this.OrderBtn6.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn6.TabIndex = 15;
            this.OrderBtn6.Text = "BESTELLING";
            this.OrderBtn6.UseVisualStyleBackColor = false;
            this.OrderBtn6.Click += new System.EventHandler(this.OrderBtn6_Click);
            // 
            // Table6_Title
            // 
            this.Table6_Title.AutoSize = true;
            this.Table6_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table6_Title.ForeColor = System.Drawing.Color.White;
            this.Table6_Title.Location = new System.Drawing.Point(28, 14);
            this.Table6_Title.Name = "Table6_Title";
            this.Table6_Title.Size = new System.Drawing.Size(80, 21);
            this.Table6_Title.TabIndex = 14;
            this.Table6_Title.Text = "TAFEL 6 | ";
            // 
            // Table7_pnl
            // 
            this.Table7_pnl.Controls.Add(this.lbl_tf_7);
            this.Table7_pnl.Controls.Add(this.lbl_w_7);
            this.Table7_pnl.Controls.Add(this.PayBtn7);
            this.Table7_pnl.Controls.Add(this.ReservationBtn7);
            this.Table7_pnl.Controls.Add(this.OrderBtn7);
            this.Table7_pnl.Controls.Add(this.Table7_Title);
            this.Table7_pnl.Location = new System.Drawing.Point(295, 304);
            this.Table7_pnl.Name = "Table7_pnl";
            this.Table7_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table7_pnl.TabIndex = 20;
            // 
            // lbl_tf_7
            // 
            this.lbl_tf_7.AutoSize = true;
            this.lbl_tf_7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_7.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_7.Location = new System.Drawing.Point(101, 14);
            this.lbl_tf_7.Name = "lbl_tf_7";
            this.lbl_tf_7.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_7.TabIndex = 54;
            this.lbl_tf_7.Text = "asdasd";
            // 
            // lbl_w_7
            // 
            this.lbl_w_7.AutoSize = true;
            this.lbl_w_7.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_7.ForeColor = System.Drawing.Color.White;
            this.lbl_w_7.Location = new System.Drawing.Point(31, 178);
            this.lbl_w_7.Name = "lbl_w_7";
            this.lbl_w_7.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_7.TabIndex = 53;
            this.lbl_w_7.Text = "Geen lopende order";
            // 
            // PayBtn7
            // 
            this.PayBtn7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn7.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn7.ForeColor = System.Drawing.Color.White;
            this.PayBtn7.Location = new System.Drawing.Point(27, 139);
            this.PayBtn7.Name = "PayBtn7";
            this.PayBtn7.Size = new System.Drawing.Size(216, 38);
            this.PayBtn7.TabIndex = 17;
            this.PayBtn7.Text = "AFREKENEN";
            this.PayBtn7.UseVisualStyleBackColor = false;
            this.PayBtn7.Click += new System.EventHandler(this.PayBtn7_Click);
            // 
            // ReservationBtn7
            // 
            this.ReservationBtn7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationBtn7.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ReservationBtn7.ForeColor = System.Drawing.Color.White;
            this.ReservationBtn7.Location = new System.Drawing.Point(27, 95);
            this.ReservationBtn7.Name = "ReservationBtn7";
            this.ReservationBtn7.Size = new System.Drawing.Size(216, 38);
            this.ReservationBtn7.TabIndex = 16;
            this.ReservationBtn7.Text = "RESERVATIE";
            this.ReservationBtn7.UseVisualStyleBackColor = false;
            this.ReservationBtn7.Click += new System.EventHandler(this.ReservationBtn7_Click);
            // 
            // OrderBtn7
            // 
            this.OrderBtn7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn7.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn7.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn7.ForeColor = System.Drawing.Color.White;
            this.OrderBtn7.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn7.Name = "OrderBtn7";
            this.OrderBtn7.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn7.TabIndex = 15;
            this.OrderBtn7.Text = "BESTELLING";
            this.OrderBtn7.UseVisualStyleBackColor = false;
            this.OrderBtn7.Click += new System.EventHandler(this.OrderBtn7_Click);
            // 
            // Table7_Title
            // 
            this.Table7_Title.AutoSize = true;
            this.Table7_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table7_Title.ForeColor = System.Drawing.Color.White;
            this.Table7_Title.Location = new System.Drawing.Point(23, 14);
            this.Table7_Title.Name = "Table7_Title";
            this.Table7_Title.Size = new System.Drawing.Size(80, 21);
            this.Table7_Title.TabIndex = 14;
            this.Table7_Title.Text = "TAFEL 7 | ";
            // 
            // Table2_pnl
            // 
            this.Table2_pnl.Controls.Add(this.lbl_tf_2);
            this.Table2_pnl.Controls.Add(this.label9);
            this.Table2_pnl.Controls.Add(this.lbl_w_2);
            this.Table2_pnl.Controls.Add(this.PayBtn2);
            this.Table2_pnl.Controls.Add(this.ReservationBtn2);
            this.Table2_pnl.Controls.Add(this.OrderBtn2);
            this.Table2_pnl.Controls.Add(this.Table2_Title);
            this.Table2_pnl.Location = new System.Drawing.Point(295, 82);
            this.Table2_pnl.Name = "Table2_pnl";
            this.Table2_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table2_pnl.TabIndex = 19;
            // 
            // lbl_tf_2
            // 
            this.lbl_tf_2.AutoSize = true;
            this.lbl_tf_2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_2.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_2.Location = new System.Drawing.Point(104, 15);
            this.lbl_tf_2.Name = "lbl_tf_2";
            this.lbl_tf_2.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_2.TabIndex = 52;
            this.lbl_tf_2.Text = "asdasd";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(72, -7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(143, 21);
            this.label9.TabIndex = 51;
            this.label9.Text = "Gerecht is Gereed";
            // 
            // lbl_w_2
            // 
            this.lbl_w_2.AutoSize = true;
            this.lbl_w_2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_2.ForeColor = System.Drawing.Color.White;
            this.lbl_w_2.Location = new System.Drawing.Point(28, 177);
            this.lbl_w_2.Name = "lbl_w_2";
            this.lbl_w_2.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_2.TabIndex = 23;
            this.lbl_w_2.Text = "Geen lopende order";
            // 
            // PayBtn2
            // 
            this.PayBtn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn2.ForeColor = System.Drawing.Color.White;
            this.PayBtn2.Location = new System.Drawing.Point(27, 139);
            this.PayBtn2.Name = "PayBtn2";
            this.PayBtn2.Size = new System.Drawing.Size(216, 38);
            this.PayBtn2.TabIndex = 17;
            this.PayBtn2.Text = "AFREKENEN";
            this.PayBtn2.UseVisualStyleBackColor = false;
            this.PayBtn2.Click += new System.EventHandler(this.PayBtn2_Click);
            // 
            // ReservationBtn2
            // 
            this.ReservationBtn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationBtn2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ReservationBtn2.ForeColor = System.Drawing.Color.White;
            this.ReservationBtn2.Location = new System.Drawing.Point(27, 95);
            this.ReservationBtn2.Name = "ReservationBtn2";
            this.ReservationBtn2.Size = new System.Drawing.Size(216, 38);
            this.ReservationBtn2.TabIndex = 16;
            this.ReservationBtn2.Text = "RESERVATIE";
            this.ReservationBtn2.UseVisualStyleBackColor = false;
            this.ReservationBtn2.Click += new System.EventHandler(this.ReservationBtn2_Click);
            // 
            // OrderBtn2
            // 
            this.OrderBtn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn2.ForeColor = System.Drawing.Color.White;
            this.OrderBtn2.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn2.Name = "OrderBtn2";
            this.OrderBtn2.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn2.TabIndex = 15;
            this.OrderBtn2.Text = "BESTELLING";
            this.OrderBtn2.UseVisualStyleBackColor = false;
            this.OrderBtn2.Click += new System.EventHandler(this.OrderBtn2_Click);
            // 
            // Table2_Title
            // 
            this.Table2_Title.AutoSize = true;
            this.Table2_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table2_Title.ForeColor = System.Drawing.Color.White;
            this.Table2_Title.Location = new System.Drawing.Point(26, 14);
            this.Table2_Title.Name = "Table2_Title";
            this.Table2_Title.Size = new System.Drawing.Size(80, 21);
            this.Table2_Title.TabIndex = 14;
            this.Table2_Title.Text = "TAFEL 2 | ";
            // 
            // Table8_pnl
            // 
            this.Table8_pnl.Controls.Add(this.lbl_tf_8);
            this.Table8_pnl.Controls.Add(this.lbl_w_8);
            this.Table8_pnl.Controls.Add(this.PayBtn8);
            this.Table8_pnl.Controls.Add(this.Reser8vationBtn);
            this.Table8_pnl.Controls.Add(this.OrderBtn8);
            this.Table8_pnl.Controls.Add(this.Table8_Title);
            this.Table8_pnl.Location = new System.Drawing.Point(580, 304);
            this.Table8_pnl.Name = "Table8_pnl";
            this.Table8_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table8_pnl.TabIndex = 22;
            // 
            // lbl_tf_8
            // 
            this.lbl_tf_8.AutoSize = true;
            this.lbl_tf_8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_8.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_8.Location = new System.Drawing.Point(113, 14);
            this.lbl_tf_8.Name = "lbl_tf_8";
            this.lbl_tf_8.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_8.TabIndex = 55;
            this.lbl_tf_8.Text = "asdsad";
            // 
            // lbl_w_8
            // 
            this.lbl_w_8.AutoSize = true;
            this.lbl_w_8.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_8.ForeColor = System.Drawing.Color.White;
            this.lbl_w_8.Location = new System.Drawing.Point(32, 178);
            this.lbl_w_8.Name = "lbl_w_8";
            this.lbl_w_8.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_8.TabIndex = 54;
            this.lbl_w_8.Text = "Geen lopende order";
            // 
            // PayBtn8
            // 
            this.PayBtn8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn8.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn8.ForeColor = System.Drawing.Color.White;
            this.PayBtn8.Location = new System.Drawing.Point(27, 139);
            this.PayBtn8.Name = "PayBtn8";
            this.PayBtn8.Size = new System.Drawing.Size(216, 38);
            this.PayBtn8.TabIndex = 17;
            this.PayBtn8.Text = "AFREKENEN";
            this.PayBtn8.UseVisualStyleBackColor = false;
            this.PayBtn8.Click += new System.EventHandler(this.PayBtn8_Click);
            // 
            // Reser8vationBtn
            // 
            this.Reser8vationBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.Reser8vationBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.Reser8vationBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Reser8vationBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Reser8vationBtn.ForeColor = System.Drawing.Color.White;
            this.Reser8vationBtn.Location = new System.Drawing.Point(27, 95);
            this.Reser8vationBtn.Name = "Reser8vationBtn";
            this.Reser8vationBtn.Size = new System.Drawing.Size(216, 38);
            this.Reser8vationBtn.TabIndex = 16;
            this.Reser8vationBtn.Text = "RESERVATIE";
            this.Reser8vationBtn.UseVisualStyleBackColor = false;
            this.Reser8vationBtn.Click += new System.EventHandler(this.Reser8vationBtn_Click);
            // 
            // OrderBtn8
            // 
            this.OrderBtn8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn8.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn8.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn8.ForeColor = System.Drawing.Color.White;
            this.OrderBtn8.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn8.Name = "OrderBtn8";
            this.OrderBtn8.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn8.TabIndex = 15;
            this.OrderBtn8.Text = "BESTELLING";
            this.OrderBtn8.UseVisualStyleBackColor = false;
            this.OrderBtn8.Click += new System.EventHandler(this.OrderBtn8_Click);
            // 
            // Table8_Title
            // 
            this.Table8_Title.AutoSize = true;
            this.Table8_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table8_Title.ForeColor = System.Drawing.Color.White;
            this.Table8_Title.Location = new System.Drawing.Point(33, 14);
            this.Table8_Title.Name = "Table8_Title";
            this.Table8_Title.Size = new System.Drawing.Size(80, 21);
            this.Table8_Title.TabIndex = 14;
            this.Table8_Title.Text = "TAFEL 8 | ";
            // 
            // Table3_pnl
            // 
            this.Table3_pnl.Controls.Add(this.lbl_tf_3);
            this.Table3_pnl.Controls.Add(this.lbl_w_3);
            this.Table3_pnl.Controls.Add(this.PayBtn3);
            this.Table3_pnl.Controls.Add(this.ReservationBtn3);
            this.Table3_pnl.Controls.Add(this.OrderBtn3);
            this.Table3_pnl.Controls.Add(this.Table3_Title);
            this.Table3_pnl.Location = new System.Drawing.Point(580, 82);
            this.Table3_pnl.Name = "Table3_pnl";
            this.Table3_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table3_pnl.TabIndex = 21;
            // 
            // lbl_tf_3
            // 
            this.lbl_tf_3.AutoSize = true;
            this.lbl_tf_3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_3.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_3.Location = new System.Drawing.Point(105, 14);
            this.lbl_tf_3.Name = "lbl_tf_3";
            this.lbl_tf_3.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_3.TabIndex = 25;
            this.lbl_tf_3.Text = "asdasd";
            // 
            // lbl_w_3
            // 
            this.lbl_w_3.AutoSize = true;
            this.lbl_w_3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_3.ForeColor = System.Drawing.Color.White;
            this.lbl_w_3.Location = new System.Drawing.Point(33, 178);
            this.lbl_w_3.Name = "lbl_w_3";
            this.lbl_w_3.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_3.TabIndex = 24;
            this.lbl_w_3.Text = "Geen lopende order";
            // 
            // PayBtn3
            // 
            this.PayBtn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn3.ForeColor = System.Drawing.Color.White;
            this.PayBtn3.Location = new System.Drawing.Point(27, 139);
            this.PayBtn3.Name = "PayBtn3";
            this.PayBtn3.Size = new System.Drawing.Size(216, 38);
            this.PayBtn3.TabIndex = 17;
            this.PayBtn3.Text = "AFREKENEN";
            this.PayBtn3.UseVisualStyleBackColor = false;
            this.PayBtn3.Click += new System.EventHandler(this.PayBtn3_Click);
            // 
            // ReservationBtn3
            // 
            this.ReservationBtn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationBtn3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ReservationBtn3.ForeColor = System.Drawing.Color.White;
            this.ReservationBtn3.Location = new System.Drawing.Point(27, 95);
            this.ReservationBtn3.Name = "ReservationBtn3";
            this.ReservationBtn3.Size = new System.Drawing.Size(216, 38);
            this.ReservationBtn3.TabIndex = 16;
            this.ReservationBtn3.Text = "RESERVATIE";
            this.ReservationBtn3.UseVisualStyleBackColor = false;
            this.ReservationBtn3.Click += new System.EventHandler(this.ReservationBtn3_Click);
            // 
            // OrderBtn3
            // 
            this.OrderBtn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn3.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn3.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn3.ForeColor = System.Drawing.Color.White;
            this.OrderBtn3.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn3.Name = "OrderBtn3";
            this.OrderBtn3.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn3.TabIndex = 15;
            this.OrderBtn3.Text = "BESTELLING";
            this.OrderBtn3.UseVisualStyleBackColor = false;
            this.OrderBtn3.Click += new System.EventHandler(this.OrderBtn3_Click);
            // 
            // Table3_Title
            // 
            this.Table3_Title.AutoSize = true;
            this.Table3_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table3_Title.ForeColor = System.Drawing.Color.White;
            this.Table3_Title.Location = new System.Drawing.Point(23, 14);
            this.Table3_Title.Name = "Table3_Title";
            this.Table3_Title.Size = new System.Drawing.Size(80, 21);
            this.Table3_Title.TabIndex = 14;
            this.Table3_Title.Text = "TAFEL 3 | ";
            // 
            // Table9_pnl
            // 
            this.Table9_pnl.Controls.Add(this.lbl_tf_9);
            this.Table9_pnl.Controls.Add(this.lbl_w_9);
            this.Table9_pnl.Controls.Add(this.PayBtn9);
            this.Table9_pnl.Controls.Add(this.ReservationBtn9);
            this.Table9_pnl.Controls.Add(this.OrderBtn9);
            this.Table9_pnl.Controls.Add(this.Table9_Title);
            this.Table9_pnl.Location = new System.Drawing.Point(865, 304);
            this.Table9_pnl.Name = "Table9_pnl";
            this.Table9_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table9_pnl.TabIndex = 24;
            // 
            // lbl_tf_9
            // 
            this.lbl_tf_9.AutoSize = true;
            this.lbl_tf_9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_9.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_9.Location = new System.Drawing.Point(108, 15);
            this.lbl_tf_9.Name = "lbl_tf_9";
            this.lbl_tf_9.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_9.TabIndex = 56;
            this.lbl_tf_9.Text = "asdsad";
            // 
            // lbl_w_9
            // 
            this.lbl_w_9.AutoSize = true;
            this.lbl_w_9.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_9.ForeColor = System.Drawing.Color.White;
            this.lbl_w_9.Location = new System.Drawing.Point(31, 178);
            this.lbl_w_9.Name = "lbl_w_9";
            this.lbl_w_9.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_9.TabIndex = 55;
            this.lbl_w_9.Text = "Geen lopende order";
            // 
            // PayBtn9
            // 
            this.PayBtn9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn9.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn9.ForeColor = System.Drawing.Color.White;
            this.PayBtn9.Location = new System.Drawing.Point(27, 139);
            this.PayBtn9.Name = "PayBtn9";
            this.PayBtn9.Size = new System.Drawing.Size(216, 38);
            this.PayBtn9.TabIndex = 17;
            this.PayBtn9.Text = "AFREKENEN";
            this.PayBtn9.UseVisualStyleBackColor = false;
            this.PayBtn9.Click += new System.EventHandler(this.PayBtn9_Click);
            // 
            // ReservationBtn9
            // 
            this.ReservationBtn9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationBtn9.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ReservationBtn9.ForeColor = System.Drawing.Color.White;
            this.ReservationBtn9.Location = new System.Drawing.Point(27, 95);
            this.ReservationBtn9.Name = "ReservationBtn9";
            this.ReservationBtn9.Size = new System.Drawing.Size(216, 38);
            this.ReservationBtn9.TabIndex = 16;
            this.ReservationBtn9.Text = "RESERVATIE";
            this.ReservationBtn9.UseVisualStyleBackColor = false;
            this.ReservationBtn9.Click += new System.EventHandler(this.ReservationBtn9_Click);
            // 
            // OrderBtn9
            // 
            this.OrderBtn9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn9.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn9.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn9.ForeColor = System.Drawing.Color.White;
            this.OrderBtn9.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn9.Name = "OrderBtn9";
            this.OrderBtn9.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn9.TabIndex = 15;
            this.OrderBtn9.Text = "BESTELLING";
            this.OrderBtn9.UseVisualStyleBackColor = false;
            this.OrderBtn9.Click += new System.EventHandler(this.OrderBtn9_Click);
            // 
            // Table9_Title
            // 
            this.Table9_Title.AutoSize = true;
            this.Table9_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table9_Title.ForeColor = System.Drawing.Color.White;
            this.Table9_Title.Location = new System.Drawing.Point(31, 14);
            this.Table9_Title.Name = "Table9_Title";
            this.Table9_Title.Size = new System.Drawing.Size(80, 21);
            this.Table9_Title.TabIndex = 14;
            this.Table9_Title.Text = "TAFEL 9 | ";
            // 
            // Table4_pnl
            // 
            this.Table4_pnl.Controls.Add(this.lbl_tf_4);
            this.Table4_pnl.Controls.Add(this.lbl_w_4);
            this.Table4_pnl.Controls.Add(this.PayBtn4);
            this.Table4_pnl.Controls.Add(this.ResservationBtn4);
            this.Table4_pnl.Controls.Add(this.OrderBtn4);
            this.Table4_pnl.Controls.Add(this.Table4_tiitle);
            this.Table4_pnl.Location = new System.Drawing.Point(865, 82);
            this.Table4_pnl.Name = "Table4_pnl";
            this.Table4_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table4_pnl.TabIndex = 23;
            // 
            // lbl_tf_4
            // 
            this.lbl_tf_4.AutoSize = true;
            this.lbl_tf_4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_4.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_4.Location = new System.Drawing.Point(100, 15);
            this.lbl_tf_4.Name = "lbl_tf_4";
            this.lbl_tf_4.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_4.TabIndex = 51;
            this.lbl_tf_4.Text = "asdsad";
            // 
            // lbl_w_4
            // 
            this.lbl_w_4.AutoSize = true;
            this.lbl_w_4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_4.ForeColor = System.Drawing.Color.White;
            this.lbl_w_4.Location = new System.Drawing.Point(31, 178);
            this.lbl_w_4.Name = "lbl_w_4";
            this.lbl_w_4.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_4.TabIndex = 50;
            this.lbl_w_4.Text = "Geen lopende order";
            // 
            // PayBtn4
            // 
            this.PayBtn4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn4.ForeColor = System.Drawing.Color.White;
            this.PayBtn4.Location = new System.Drawing.Point(27, 139);
            this.PayBtn4.Name = "PayBtn4";
            this.PayBtn4.Size = new System.Drawing.Size(216, 38);
            this.PayBtn4.TabIndex = 17;
            this.PayBtn4.Text = "AFREKENEN";
            this.PayBtn4.UseVisualStyleBackColor = false;
            this.PayBtn4.Click += new System.EventHandler(this.PayBtn4_Click);
            // 
            // ResservationBtn4
            // 
            this.ResservationBtn4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ResservationBtn4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ResservationBtn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ResservationBtn4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ResservationBtn4.ForeColor = System.Drawing.Color.White;
            this.ResservationBtn4.Location = new System.Drawing.Point(27, 95);
            this.ResservationBtn4.Name = "ResservationBtn4";
            this.ResservationBtn4.Size = new System.Drawing.Size(216, 38);
            this.ResservationBtn4.TabIndex = 16;
            this.ResservationBtn4.Text = "RESERVATIE";
            this.ResservationBtn4.UseVisualStyleBackColor = false;
            this.ResservationBtn4.Click += new System.EventHandler(this.ResservationBtn4_Click);
            // 
            // OrderBtn4
            // 
            this.OrderBtn4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn4.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn4.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn4.ForeColor = System.Drawing.Color.White;
            this.OrderBtn4.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn4.Name = "OrderBtn4";
            this.OrderBtn4.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn4.TabIndex = 15;
            this.OrderBtn4.Text = "BESTELLING";
            this.OrderBtn4.UseVisualStyleBackColor = false;
            this.OrderBtn4.Click += new System.EventHandler(this.OrderBtn4_Click);
            // 
            // Table4_tiitle
            // 
            this.Table4_tiitle.AutoSize = true;
            this.Table4_tiitle.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table4_tiitle.ForeColor = System.Drawing.Color.White;
            this.Table4_tiitle.Location = new System.Drawing.Point(23, 14);
            this.Table4_tiitle.Name = "Table4_tiitle";
            this.Table4_tiitle.Size = new System.Drawing.Size(80, 21);
            this.Table4_tiitle.TabIndex = 14;
            this.Table4_tiitle.Text = "TAFEL 4 | ";
            // 
            // Table10_pnl
            // 
            this.Table10_pnl.Controls.Add(this.lbl_tf_10);
            this.Table10_pnl.Controls.Add(this.lbl_w_10);
            this.Table10_pnl.Controls.Add(this.PayBtn10);
            this.Table10_pnl.Controls.Add(this.ReservationBtn10);
            this.Table10_pnl.Controls.Add(this.OrderBtn10);
            this.Table10_pnl.Controls.Add(this.Table10_Title);
            this.Table10_pnl.Location = new System.Drawing.Point(1153, 304);
            this.Table10_pnl.Name = "Table10_pnl";
            this.Table10_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table10_pnl.TabIndex = 26;
            // 
            // lbl_tf_10
            // 
            this.lbl_tf_10.AutoSize = true;
            this.lbl_tf_10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_10.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_10.Location = new System.Drawing.Point(109, 14);
            this.lbl_tf_10.Name = "lbl_tf_10";
            this.lbl_tf_10.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_10.TabIndex = 57;
            this.lbl_tf_10.Text = "asdsda";
            // 
            // lbl_w_10
            // 
            this.lbl_w_10.AutoSize = true;
            this.lbl_w_10.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_10.ForeColor = System.Drawing.Color.White;
            this.lbl_w_10.Location = new System.Drawing.Point(32, 178);
            this.lbl_w_10.Name = "lbl_w_10";
            this.lbl_w_10.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_10.TabIndex = 56;
            this.lbl_w_10.Text = "Geen lopende order";
            // 
            // PayBtn10
            // 
            this.PayBtn10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn10.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn10.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn10.ForeColor = System.Drawing.Color.White;
            this.PayBtn10.Location = new System.Drawing.Point(27, 139);
            this.PayBtn10.Name = "PayBtn10";
            this.PayBtn10.Size = new System.Drawing.Size(216, 38);
            this.PayBtn10.TabIndex = 17;
            this.PayBtn10.Text = "AFREKENEN";
            this.PayBtn10.UseVisualStyleBackColor = false;
            this.PayBtn10.Click += new System.EventHandler(this.PayBtn10_Click);
            // 
            // ReservationBtn10
            // 
            this.ReservationBtn10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn10.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationBtn10.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ReservationBtn10.ForeColor = System.Drawing.Color.White;
            this.ReservationBtn10.Location = new System.Drawing.Point(27, 95);
            this.ReservationBtn10.Name = "ReservationBtn10";
            this.ReservationBtn10.Size = new System.Drawing.Size(216, 38);
            this.ReservationBtn10.TabIndex = 16;
            this.ReservationBtn10.Text = "RESERVATIE";
            this.ReservationBtn10.UseVisualStyleBackColor = false;
            this.ReservationBtn10.Click += new System.EventHandler(this.ReservationBtn10_Click);
            // 
            // OrderBtn10
            // 
            this.OrderBtn10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn10.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn10.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn10.ForeColor = System.Drawing.Color.White;
            this.OrderBtn10.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn10.Name = "OrderBtn10";
            this.OrderBtn10.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn10.TabIndex = 15;
            this.OrderBtn10.Text = "BESTELLING";
            this.OrderBtn10.UseVisualStyleBackColor = false;
            this.OrderBtn10.Click += new System.EventHandler(this.OrderBtn10_Click);
            // 
            // Table10_Title
            // 
            this.Table10_Title.AutoSize = true;
            this.Table10_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table10_Title.ForeColor = System.Drawing.Color.White;
            this.Table10_Title.Location = new System.Drawing.Point(23, 14);
            this.Table10_Title.Name = "Table10_Title";
            this.Table10_Title.Size = new System.Drawing.Size(89, 21);
            this.Table10_Title.TabIndex = 14;
            this.Table10_Title.Text = "TAFEL 10 | ";
            // 
            // Table5_pnl
            // 
            this.Table5_pnl.Controls.Add(this.lbl_tf_5);
            this.Table5_pnl.Controls.Add(this.lbl_w_5);
            this.Table5_pnl.Controls.Add(this.PayBtn5);
            this.Table5_pnl.Controls.Add(this.ReservationBtn5);
            this.Table5_pnl.Controls.Add(this.OrderBtn5);
            this.Table5_pnl.Controls.Add(this.Table5_Title);
            this.Table5_pnl.Location = new System.Drawing.Point(1153, 82);
            this.Table5_pnl.Name = "Table5_pnl";
            this.Table5_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table5_pnl.TabIndex = 25;
            // 
            // lbl_tf_5
            // 
            this.lbl_tf_5.AutoSize = true;
            this.lbl_tf_5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_5.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_5.Location = new System.Drawing.Point(109, 15);
            this.lbl_tf_5.Name = "lbl_tf_5";
            this.lbl_tf_5.Size = new System.Drawing.Size(52, 21);
            this.lbl_tf_5.TabIndex = 52;
            this.lbl_tf_5.Text = "asdas";
            // 
            // lbl_w_5
            // 
            this.lbl_w_5.AutoSize = true;
            this.lbl_w_5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_5.ForeColor = System.Drawing.Color.White;
            this.lbl_w_5.Location = new System.Drawing.Point(36, 178);
            this.lbl_w_5.Name = "lbl_w_5";
            this.lbl_w_5.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_5.TabIndex = 51;
            this.lbl_w_5.Text = "Geen lopende order";
            // 
            // PayBtn5
            // 
            this.PayBtn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn5.ForeColor = System.Drawing.Color.White;
            this.PayBtn5.Location = new System.Drawing.Point(27, 139);
            this.PayBtn5.Name = "PayBtn5";
            this.PayBtn5.Size = new System.Drawing.Size(216, 38);
            this.PayBtn5.TabIndex = 17;
            this.PayBtn5.Text = "AFREKENEN";
            this.PayBtn5.UseVisualStyleBackColor = false;
            this.PayBtn5.Click += new System.EventHandler(this.PayBtn5_Click);
            // 
            // ReservationBtn5
            // 
            this.ReservationBtn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationBtn5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ReservationBtn5.ForeColor = System.Drawing.Color.White;
            this.ReservationBtn5.Location = new System.Drawing.Point(27, 95);
            this.ReservationBtn5.Name = "ReservationBtn5";
            this.ReservationBtn5.Size = new System.Drawing.Size(216, 38);
            this.ReservationBtn5.TabIndex = 16;
            this.ReservationBtn5.Text = "RESERVATIE";
            this.ReservationBtn5.UseVisualStyleBackColor = false;
            this.ReservationBtn5.Click += new System.EventHandler(this.ReservationBtn5_Click);
            // 
            // OrderBtn5
            // 
            this.OrderBtn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn5.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn5.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn5.ForeColor = System.Drawing.Color.White;
            this.OrderBtn5.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn5.Name = "OrderBtn5";
            this.OrderBtn5.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn5.TabIndex = 15;
            this.OrderBtn5.Text = "BESTELLING";
            this.OrderBtn5.UseVisualStyleBackColor = false;
            this.OrderBtn5.Click += new System.EventHandler(this.OrderBtn5_Click);
            // 
            // Table5_Title
            // 
            this.Table5_Title.AutoSize = true;
            this.Table5_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table5_Title.ForeColor = System.Drawing.Color.White;
            this.Table5_Title.Location = new System.Drawing.Point(23, 14);
            this.Table5_Title.Name = "Table5_Title";
            this.Table5_Title.Size = new System.Drawing.Size(80, 21);
            this.Table5_Title.TabIndex = 14;
            this.Table5_Title.Text = "TAFEL 5 | ";
            // 
            // AllOrdersBtn
            // 
            this.AllOrdersBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllOrdersBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllOrdersBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AllOrdersBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AllOrdersBtn.ForeColor = System.Drawing.Color.White;
            this.AllOrdersBtn.Location = new System.Drawing.Point(121, 512);
            this.AllOrdersBtn.Name = "AllOrdersBtn";
            this.AllOrdersBtn.Size = new System.Drawing.Size(216, 38);
            this.AllOrdersBtn.TabIndex = 18;
            this.AllOrdersBtn.Text = "ALLE BESTELLINGEN";
            this.AllOrdersBtn.UseVisualStyleBackColor = false;
            this.AllOrdersBtn.Click += new System.EventHandler(this.AllOrdersBtn_Click);
            // 
            // AllreservationsBtn
            // 
            this.AllreservationsBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllreservationsBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllreservationsBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AllreservationsBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AllreservationsBtn.ForeColor = System.Drawing.Color.White;
            this.AllreservationsBtn.Location = new System.Drawing.Point(360, 512);
            this.AllreservationsBtn.Name = "AllreservationsBtn";
            this.AllreservationsBtn.Size = new System.Drawing.Size(216, 38);
            this.AllreservationsBtn.TabIndex = 27;
            this.AllreservationsBtn.Text = "ALLE RESERVERINGEN";
            this.AllreservationsBtn.UseVisualStyleBackColor = false;
            this.AllreservationsBtn.Click += new System.EventHandler(this.AllreservationsBtn_Click);
            // 
            // Order_pnl
            // 
            this.Order_pnl.Controls.Add(this.AllOrders_pnl);
            this.Order_pnl.Controls.Add(this.ChangeRes_pnl);
            this.Order_pnl.Controls.Add(this.Res_pnl);
            this.Order_pnl.Controls.Add(this.pictureBox3);
            this.Order_pnl.Controls.Add(this.AddRes_pnl);
            this.Order_pnl.Controls.Add(this.AddResBtn);
            this.Order_pnl.Controls.Add(this.AllResBtn);
            this.Order_pnl.Controls.Add(this.AddOrder_pnl);
            this.Order_pnl.Controls.Add(this.BackToTablesBtn);
            this.Order_pnl.Controls.Add(this.ChangeAmount_pnl);
            this.Order_pnl.Controls.Add(this.AllOrdersBtn2);
            this.Order_pnl.Controls.Add(this.AddBtn);
            this.Order_pnl.Controls.Add(this.pictureBox2);
            this.Order_pnl.Location = new System.Drawing.Point(8, 52);
            this.Order_pnl.Name = "Order_pnl";
            this.Order_pnl.Size = new System.Drawing.Size(1407, 551);
            this.Order_pnl.TabIndex = 28;
            this.Order_pnl.Visible = false;
            // 
            // AllOrders_pnl
            // 
            this.AllOrders_pnl.Controls.Add(this.ChooseTableDD);
            this.AllOrders_pnl.Controls.Add(this.ChooseTablelbl);
            this.AllOrders_pnl.Controls.Add(this.ChangeBtn);
            this.AllOrders_pnl.Controls.Add(this.DeleteOrderBtn);
            this.AllOrders_pnl.Controls.Add(this.DeleteOrderItemBtn);
            this.AllOrders_pnl.Controls.Add(this.AllOrderslv);
            this.AllOrders_pnl.Location = new System.Drawing.Point(322, 6);
            this.AllOrders_pnl.Name = "AllOrders_pnl";
            this.AllOrders_pnl.Size = new System.Drawing.Size(773, 491);
            this.AllOrders_pnl.TabIndex = 31;
            // 
            // ChooseTableDD
            // 
            this.ChooseTableDD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ChooseTableDD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ChooseTableDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChooseTableDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.ChooseTableDD.ForeColor = System.Drawing.Color.White;
            this.ChooseTableDD.FormattingEnabled = true;
            this.ChooseTableDD.Location = new System.Drawing.Point(87, 130);
            this.ChooseTableDD.Name = "ChooseTableDD";
            this.ChooseTableDD.Size = new System.Drawing.Size(191, 29);
            this.ChooseTableDD.TabIndex = 46;
            this.ChooseTableDD.SelectedIndexChanged += new System.EventHandler(this.ChooseTableDD_SelectedIndexChanged);
            // 
            // ChooseTablelbl
            // 
            this.ChooseTablelbl.AutoSize = true;
            this.ChooseTablelbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.ChooseTablelbl.ForeColor = System.Drawing.Color.White;
            this.ChooseTablelbl.Location = new System.Drawing.Point(16, 133);
            this.ChooseTablelbl.Name = "ChooseTablelbl";
            this.ChooseTablelbl.Size = new System.Drawing.Size(54, 21);
            this.ChooseTablelbl.TabIndex = 45;
            this.ChooseTablelbl.Text = "TAFEL";
            // 
            // ChangeBtn
            // 
            this.ChangeBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ChangeBtn.FlatAppearance.BorderSize = 0;
            this.ChangeBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.ChangeBtn.ForeColor = System.Drawing.Color.White;
            this.ChangeBtn.Location = new System.Drawing.Point(537, 384);
            this.ChangeBtn.Name = "ChangeBtn";
            this.ChangeBtn.Size = new System.Drawing.Size(219, 38);
            this.ChangeBtn.TabIndex = 3;
            this.ChangeBtn.Text = "BEWERKEN";
            this.ChangeBtn.UseVisualStyleBackColor = false;
            this.ChangeBtn.Click += new System.EventHandler(this.ChangeBtn_Click);
            // 
            // DeleteOrderBtn
            // 
            this.DeleteOrderBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(0)))), ((int)(((byte)(14)))));
            this.DeleteOrderBtn.FlatAppearance.BorderSize = 0;
            this.DeleteOrderBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteOrderBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.DeleteOrderBtn.ForeColor = System.Drawing.Color.White;
            this.DeleteOrderBtn.Location = new System.Drawing.Point(263, 384);
            this.DeleteOrderBtn.Name = "DeleteOrderBtn";
            this.DeleteOrderBtn.Size = new System.Drawing.Size(219, 38);
            this.DeleteOrderBtn.TabIndex = 2;
            this.DeleteOrderBtn.Text = "VERWIJDER BESTELLING";
            this.DeleteOrderBtn.UseVisualStyleBackColor = false;
            this.DeleteOrderBtn.Click += new System.EventHandler(this.DeleteOrderBtn_Click);
            // 
            // DeleteOrderItemBtn
            // 
            this.DeleteOrderItemBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(0)))), ((int)(((byte)(14)))));
            this.DeleteOrderItemBtn.FlatAppearance.BorderSize = 0;
            this.DeleteOrderItemBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteOrderItemBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.DeleteOrderItemBtn.ForeColor = System.Drawing.Color.White;
            this.DeleteOrderItemBtn.Location = new System.Drawing.Point(14, 384);
            this.DeleteOrderItemBtn.Name = "DeleteOrderItemBtn";
            this.DeleteOrderItemBtn.Size = new System.Drawing.Size(201, 38);
            this.DeleteOrderItemBtn.TabIndex = 1;
            this.DeleteOrderItemBtn.Text = "VERWIJDER GERECHT";
            this.DeleteOrderItemBtn.UseVisualStyleBackColor = false;
            this.DeleteOrderItemBtn.Click += new System.EventHandler(this.DeleteOrderItemBtn_Click);
            // 
            // AllOrderslv
            // 
            this.AllOrderslv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllOrderslv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.order_id,
            this.orderTableId,
            this.itemName_,
            this.aantal1,
            this.orderItemStatus_});
            this.AllOrderslv.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AllOrderslv.ForeColor = System.Drawing.Color.White;
            this.AllOrderslv.FullRowSelect = true;
            this.AllOrderslv.HideSelection = false;
            this.AllOrderslv.Location = new System.Drawing.Point(13, 173);
            this.AllOrderslv.Name = "AllOrderslv";
            this.AllOrderslv.Size = new System.Drawing.Size(743, 185);
            this.AllOrderslv.TabIndex = 0;
            this.AllOrderslv.UseCompatibleStateImageBehavior = false;
            this.AllOrderslv.View = System.Windows.Forms.View.Details;
            // 
            // order_id
            // 
            this.order_id.Text = "ID";
            this.order_id.Width = 63;
            // 
            // orderTableId
            // 
            this.orderTableId.Text = "Tafel";
            // 
            // itemName_
            // 
            this.itemName_.Text = "Consumptie";
            this.itemName_.Width = 275;
            // 
            // aantal1
            // 
            this.aantal1.Text = "Aantal";
            // 
            // orderItemStatus_
            // 
            this.orderItemStatus_.Text = "Status";
            this.orderItemStatus_.Width = 153;
            // 
            // ChangeRes_pnl
            // 
            this.ChangeRes_pnl.Controls.Add(this.TafelResDD);
            this.ChangeRes_pnl.Controls.Add(this.aamBox);
            this.ChangeRes_pnl.Controls.Add(this.naamLbl);
            this.ChangeRes_pnl.Controls.Add(this.ChangeResAcceptBtn);
            this.ChangeRes_pnl.Controls.Add(this.aantekeningBox);
            this.ChangeRes_pnl.Controls.Add(this.aantekeninglbl);
            this.ChangeRes_pnl.Controls.Add(this.datumBox);
            this.ChangeRes_pnl.Controls.Add(this.emailBox);
            this.ChangeRes_pnl.Controls.Add(this.telBox);
            this.ChangeRes_pnl.Controls.Add(this.datumLbl);
            this.ChangeRes_pnl.Controls.Add(this.emailLbl);
            this.ChangeRes_pnl.Controls.Add(this.telnrLbl);
            this.ChangeRes_pnl.Controls.Add(this.ResTafellbl);
            this.ChangeRes_pnl.Location = new System.Drawing.Point(272, 0);
            this.ChangeRes_pnl.Name = "ChangeRes_pnl";
            this.ChangeRes_pnl.Size = new System.Drawing.Size(879, 503);
            this.ChangeRes_pnl.TabIndex = 44;
            // 
            // TafelResDD
            // 
            this.TafelResDD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.TafelResDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.TafelResDD.ForeColor = System.Drawing.Color.White;
            this.TafelResDD.Location = new System.Drawing.Point(160, 101);
            this.TafelResDD.Name = "TafelResDD";
            this.TafelResDD.Size = new System.Drawing.Size(191, 29);
            this.TafelResDD.TabIndex = 46;
            // 
            // aamBox
            // 
            this.aamBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.aamBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.aamBox.ForeColor = System.Drawing.Color.White;
            this.aamBox.Location = new System.Drawing.Point(160, 162);
            this.aamBox.Name = "aamBox";
            this.aamBox.Size = new System.Drawing.Size(191, 29);
            this.aamBox.TabIndex = 45;
            // 
            // naamLbl
            // 
            this.naamLbl.AutoSize = true;
            this.naamLbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.naamLbl.ForeColor = System.Drawing.Color.White;
            this.naamLbl.Location = new System.Drawing.Point(51, 165);
            this.naamLbl.Name = "naamLbl";
            this.naamLbl.Size = new System.Drawing.Size(60, 21);
            this.naamLbl.TabIndex = 44;
            this.naamLbl.Text = "NAAM";
            // 
            // ChangeResAcceptBtn
            // 
            this.ChangeResAcceptBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ChangeResAcceptBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ChangeResAcceptBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeResAcceptBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ChangeResAcceptBtn.ForeColor = System.Drawing.Color.White;
            this.ChangeResAcceptBtn.Location = new System.Drawing.Point(583, 254);
            this.ChangeResAcceptBtn.Name = "ChangeResAcceptBtn";
            this.ChangeResAcceptBtn.Size = new System.Drawing.Size(172, 39);
            this.ChangeResAcceptBtn.TabIndex = 43;
            this.ChangeResAcceptBtn.Text = "BEVESTIGEN";
            this.ChangeResAcceptBtn.UseVisualStyleBackColor = false;
            this.ChangeResAcceptBtn.Click += new System.EventHandler(this.ChangeResAcceptBtn_Click);
            // 
            // aantekeningBox
            // 
            this.aantekeningBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.aantekeningBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.aantekeningBox.ForeColor = System.Drawing.Color.White;
            this.aantekeningBox.Location = new System.Drawing.Point(413, 141);
            this.aantekeningBox.Multiline = true;
            this.aantekeningBox.Name = "aantekeningBox";
            this.aantekeningBox.Size = new System.Drawing.Size(342, 101);
            this.aantekeningBox.TabIndex = 18;
            // 
            // aantekeninglbl
            // 
            this.aantekeninglbl.AutoSize = true;
            this.aantekeninglbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.aantekeninglbl.ForeColor = System.Drawing.Color.White;
            this.aantekeninglbl.Location = new System.Drawing.Point(408, 103);
            this.aantekeninglbl.Name = "aantekeninglbl";
            this.aantekeninglbl.Size = new System.Drawing.Size(124, 21);
            this.aantekeninglbl.TabIndex = 17;
            this.aantekeninglbl.Text = "AANTEKENING";
            // 
            // datumBox
            // 
            this.datumBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.datumBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.datumBox.ForeColor = System.Drawing.Color.White;
            this.datumBox.Location = new System.Drawing.Point(160, 320);
            this.datumBox.Name = "datumBox";
            this.datumBox.Size = new System.Drawing.Size(191, 29);
            this.datumBox.TabIndex = 16;
            // 
            // emailBox
            // 
            this.emailBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.emailBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.emailBox.ForeColor = System.Drawing.Color.White;
            this.emailBox.Location = new System.Drawing.Point(160, 264);
            this.emailBox.Name = "emailBox";
            this.emailBox.Size = new System.Drawing.Size(191, 29);
            this.emailBox.TabIndex = 15;
            // 
            // telBox
            // 
            this.telBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.telBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.telBox.ForeColor = System.Drawing.Color.White;
            this.telBox.Location = new System.Drawing.Point(160, 214);
            this.telBox.Name = "telBox";
            this.telBox.Size = new System.Drawing.Size(191, 29);
            this.telBox.TabIndex = 14;
            // 
            // datumLbl
            // 
            this.datumLbl.AutoSize = true;
            this.datumLbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.datumLbl.ForeColor = System.Drawing.Color.White;
            this.datumLbl.Location = new System.Drawing.Point(50, 323);
            this.datumLbl.Name = "datumLbl";
            this.datumLbl.Size = new System.Drawing.Size(68, 21);
            this.datumLbl.TabIndex = 12;
            this.datumLbl.Text = "DATUM";
            // 
            // emailLbl
            // 
            this.emailLbl.AutoSize = true;
            this.emailLbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.emailLbl.ForeColor = System.Drawing.Color.White;
            this.emailLbl.Location = new System.Drawing.Point(51, 267);
            this.emailLbl.Name = "emailLbl";
            this.emailLbl.Size = new System.Drawing.Size(58, 21);
            this.emailLbl.TabIndex = 11;
            this.emailLbl.Text = "EMAIL";
            // 
            // telnrLbl
            // 
            this.telnrLbl.AutoSize = true;
            this.telnrLbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.telnrLbl.ForeColor = System.Drawing.Color.White;
            this.telnrLbl.Location = new System.Drawing.Point(51, 217);
            this.telnrLbl.Name = "telnrLbl";
            this.telnrLbl.Size = new System.Drawing.Size(67, 21);
            this.telnrLbl.TabIndex = 10;
            this.telnrLbl.Text = "TEL NR.";
            // 
            // ResTafellbl
            // 
            this.ResTafellbl.AutoSize = true;
            this.ResTafellbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.ResTafellbl.ForeColor = System.Drawing.Color.White;
            this.ResTafellbl.Location = new System.Drawing.Point(50, 103);
            this.ResTafellbl.Name = "ResTafellbl";
            this.ResTafellbl.Size = new System.Drawing.Size(54, 21);
            this.ResTafellbl.TabIndex = 9;
            this.ResTafellbl.Text = "TAFEL";
            // 
            // Res_pnl
            // 
            this.Res_pnl.Controls.Add(this.ChangeResBtn);
            this.Res_pnl.Controls.Add(this.DeleteResBtn);
            this.Res_pnl.Controls.Add(this.Reservationlv);
            this.Res_pnl.Location = new System.Drawing.Point(270, 3);
            this.Res_pnl.Name = "Res_pnl";
            this.Res_pnl.Size = new System.Drawing.Size(879, 491);
            this.Res_pnl.TabIndex = 41;
            // 
            // ChangeResBtn
            // 
            this.ChangeResBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ChangeResBtn.FlatAppearance.BorderSize = 0;
            this.ChangeResBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeResBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.ChangeResBtn.ForeColor = System.Drawing.Color.White;
            this.ChangeResBtn.Location = new System.Drawing.Point(630, 384);
            this.ChangeResBtn.Name = "ChangeResBtn";
            this.ChangeResBtn.Size = new System.Drawing.Size(219, 38);
            this.ChangeResBtn.TabIndex = 3;
            this.ChangeResBtn.Text = "BEWERKEN";
            this.ChangeResBtn.UseVisualStyleBackColor = false;
            this.ChangeResBtn.Click += new System.EventHandler(this.ChangeResBtn_Click);
            // 
            // DeleteResBtn
            // 
            this.DeleteResBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(133)))), ((int)(((byte)(0)))), ((int)(((byte)(14)))));
            this.DeleteResBtn.FlatAppearance.BorderSize = 0;
            this.DeleteResBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.DeleteResBtn.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.DeleteResBtn.ForeColor = System.Drawing.Color.White;
            this.DeleteResBtn.Location = new System.Drawing.Point(14, 384);
            this.DeleteResBtn.Name = "DeleteResBtn";
            this.DeleteResBtn.Size = new System.Drawing.Size(262, 38);
            this.DeleteResBtn.TabIndex = 1;
            this.DeleteResBtn.Text = "VERWIJDER RESERVERING";
            this.DeleteResBtn.UseVisualStyleBackColor = false;
            this.DeleteResBtn.Click += new System.EventHandler(this.DeleteResBtn_Click);
            // 
            // Reservationlv
            // 
            this.Reservationlv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.Reservationlv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.reservationId,
            this.tableId,
            this.reservationName,
            this.reservationTel,
            this.reservationEmail,
            this.reservationComment,
            this.reservationDate});
            this.Reservationlv.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.Reservationlv.ForeColor = System.Drawing.Color.White;
            this.Reservationlv.FullRowSelect = true;
            this.Reservationlv.HideSelection = false;
            this.Reservationlv.Location = new System.Drawing.Point(13, 98);
            this.Reservationlv.Name = "Reservationlv";
            this.Reservationlv.Size = new System.Drawing.Size(836, 260);
            this.Reservationlv.TabIndex = 0;
            this.Reservationlv.UseCompatibleStateImageBehavior = false;
            this.Reservationlv.View = System.Windows.Forms.View.Details;
            // 
            // reservationId
            // 
            this.reservationId.Text = "ID";
            // 
            // tableId
            // 
            this.tableId.Text = "Tafel";
            // 
            // reservationName
            // 
            this.reservationName.Text = "Naam";
            this.reservationName.Width = 95;
            // 
            // reservationTel
            // 
            this.reservationTel.Text = "Tel nr.";
            this.reservationTel.Width = 101;
            // 
            // reservationEmail
            // 
            this.reservationEmail.Text = "Email";
            this.reservationEmail.Width = 86;
            // 
            // reservationComment
            // 
            this.reservationComment.Text = "Opmerking";
            this.reservationComment.Width = 289;
            // 
            // reservationDate
            // 
            this.reservationDate.Text = "Datum";
            this.reservationDate.Width = 99;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox3.Image = global::ChapooUI.Properties.Resources.output_onlinepngtools__7_;
            this.pictureBox3.Location = new System.Drawing.Point(35, 248);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(65, 63);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 38;
            this.pictureBox3.TabStop = false;
            // 
            // AddRes_pnl
            // 
            this.AddRes_pnl.Controls.Add(this.AddNaamDD);
            this.AddRes_pnl.Controls.Add(this.label1);
            this.AddRes_pnl.Controls.Add(this.BevestigResBtn);
            this.AddRes_pnl.Controls.Add(this.AddOpmerking);
            this.AddRes_pnl.Controls.Add(this.label2);
            this.AddRes_pnl.Controls.Add(this.AddDatum);
            this.AddRes_pnl.Controls.Add(this.AddEmail);
            this.AddRes_pnl.Controls.Add(this.Addtel);
            this.AddRes_pnl.Controls.Add(this.AddTafelDD);
            this.AddRes_pnl.Controls.Add(this.label3);
            this.AddRes_pnl.Controls.Add(this.label4);
            this.AddRes_pnl.Controls.Add(this.label5);
            this.AddRes_pnl.Controls.Add(this.label6);
            this.AddRes_pnl.Location = new System.Drawing.Point(276, 5);
            this.AddRes_pnl.Name = "AddRes_pnl";
            this.AddRes_pnl.Size = new System.Drawing.Size(879, 491);
            this.AddRes_pnl.TabIndex = 46;
            // 
            // AddNaamDD
            // 
            this.AddNaamDD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddNaamDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.AddNaamDD.ForeColor = System.Drawing.Color.White;
            this.AddNaamDD.Location = new System.Drawing.Point(160, 162);
            this.AddNaamDD.Name = "AddNaamDD";
            this.AddNaamDD.Size = new System.Drawing.Size(191, 29);
            this.AddNaamDD.TabIndex = 45;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(51, 165);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(60, 21);
            this.label1.TabIndex = 44;
            this.label1.Text = "NAAM";
            // 
            // BevestigResBtn
            // 
            this.BevestigResBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.BevestigResBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.BevestigResBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BevestigResBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BevestigResBtn.ForeColor = System.Drawing.Color.White;
            this.BevestigResBtn.Location = new System.Drawing.Point(583, 254);
            this.BevestigResBtn.Name = "BevestigResBtn";
            this.BevestigResBtn.Size = new System.Drawing.Size(172, 39);
            this.BevestigResBtn.TabIndex = 43;
            this.BevestigResBtn.Text = "BEVESTIGEN";
            this.BevestigResBtn.UseVisualStyleBackColor = false;
            this.BevestigResBtn.Click += new System.EventHandler(this.BevestigResBtn_Click_1);
            // 
            // AddOpmerking
            // 
            this.AddOpmerking.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddOpmerking.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.AddOpmerking.ForeColor = System.Drawing.Color.White;
            this.AddOpmerking.Location = new System.Drawing.Point(413, 141);
            this.AddOpmerking.Multiline = true;
            this.AddOpmerking.Name = "AddOpmerking";
            this.AddOpmerking.Size = new System.Drawing.Size(342, 101);
            this.AddOpmerking.TabIndex = 18;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(408, 103);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(124, 21);
            this.label2.TabIndex = 17;
            this.label2.Text = "AANTEKENING";
            // 
            // AddDatum
            // 
            this.AddDatum.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddDatum.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.AddDatum.ForeColor = System.Drawing.Color.White;
            this.AddDatum.Location = new System.Drawing.Point(160, 320);
            this.AddDatum.Name = "AddDatum";
            this.AddDatum.Size = new System.Drawing.Size(191, 29);
            this.AddDatum.TabIndex = 16;
            // 
            // AddEmail
            // 
            this.AddEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddEmail.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.AddEmail.ForeColor = System.Drawing.Color.White;
            this.AddEmail.Location = new System.Drawing.Point(160, 264);
            this.AddEmail.Name = "AddEmail";
            this.AddEmail.Size = new System.Drawing.Size(191, 29);
            this.AddEmail.TabIndex = 15;
            // 
            // Addtel
            // 
            this.Addtel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.Addtel.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.Addtel.ForeColor = System.Drawing.Color.White;
            this.Addtel.Location = new System.Drawing.Point(160, 214);
            this.Addtel.Name = "Addtel";
            this.Addtel.Size = new System.Drawing.Size(191, 29);
            this.Addtel.TabIndex = 14;
            // 
            // AddTafelDD
            // 
            this.AddTafelDD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddTafelDD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.AddTafelDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddTafelDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.AddTafelDD.ForeColor = System.Drawing.Color.White;
            this.AddTafelDD.FormattingEnabled = true;
            this.AddTafelDD.Location = new System.Drawing.Point(160, 101);
            this.AddTafelDD.Name = "AddTafelDD";
            this.AddTafelDD.Size = new System.Drawing.Size(191, 29);
            this.AddTafelDD.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(50, 323);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 21);
            this.label3.TabIndex = 12;
            this.label3.Text = "DATUM";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(51, 267);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(58, 21);
            this.label4.TabIndex = 11;
            this.label4.Text = "EMAIL";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(51, 217);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 21);
            this.label5.TabIndex = 10;
            this.label5.Text = "TEL NR.";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(50, 103);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(54, 21);
            this.label6.TabIndex = 9;
            this.label6.Text = "TAFEL";
            // 
            // AddResBtn
            // 
            this.AddResBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddResBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddResBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddResBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AddResBtn.ForeColor = System.Drawing.Color.White;
            this.AddResBtn.Location = new System.Drawing.Point(35, 323);
            this.AddResBtn.Name = "AddResBtn";
            this.AddResBtn.Size = new System.Drawing.Size(216, 38);
            this.AddResBtn.TabIndex = 37;
            this.AddResBtn.Text = "RESERVERING TOEVOEGEN";
            this.AddResBtn.UseVisualStyleBackColor = false;
            this.AddResBtn.Click += new System.EventHandler(this.AddResBtn_Click);
            // 
            // AllResBtn
            // 
            this.AllResBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllResBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllResBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AllResBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AllResBtn.ForeColor = System.Drawing.Color.White;
            this.AllResBtn.Location = new System.Drawing.Point(35, 373);
            this.AllResBtn.Name = "AllResBtn";
            this.AllResBtn.Size = new System.Drawing.Size(216, 38);
            this.AllResBtn.TabIndex = 36;
            this.AllResBtn.Text = "ALLE RESERVERINGEN";
            this.AllResBtn.UseVisualStyleBackColor = false;
            this.AllResBtn.Click += new System.EventHandler(this.AllResBtn_Click);
            // 
            // AddOrder_pnl
            // 
            this.AddOrder_pnl.Controls.Add(this.orderslv);
            this.AddOrder_pnl.Controls.Add(this.consumptieLabel);
            this.AddOrder_pnl.Controls.Add(this.ConsumptieDD);
            this.AddOrder_pnl.Controls.Add(this.minBtn);
            this.AddOrder_pnl.Controls.Add(this.plusBtn);
            this.AddOrder_pnl.Controls.Add(this.OrderAddBtn);
            this.AddOrder_pnl.Controls.Add(this.opmerkingBox);
            this.AddOrder_pnl.Controls.Add(this.opmerkinglbl);
            this.AddOrder_pnl.Controls.Add(this.amountOrderItem);
            this.AddOrder_pnl.Controls.Add(this.aantalllbl);
            this.AddOrder_pnl.Controls.Add(this.Consumptielbl);
            this.AddOrder_pnl.Controls.Add(this.MenuDD);
            this.AddOrder_pnl.Controls.Add(this.Menulbl);
            this.AddOrder_pnl.Controls.Add(this.TafelDD);
            this.AddOrder_pnl.Controls.Add(this.tafellbl);
            this.AddOrder_pnl.Location = new System.Drawing.Point(270, 2);
            this.AddOrder_pnl.Name = "AddOrder_pnl";
            this.AddOrder_pnl.Size = new System.Drawing.Size(877, 491);
            this.AddOrder_pnl.TabIndex = 35;
            // 
            // orderslv
            // 
            this.orderslv.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.orderslv.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.gerecht,
            this.aantal});
            this.orderslv.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.orderslv.ForeColor = System.Drawing.Color.White;
            this.orderslv.FullRowSelect = true;
            this.orderslv.HideSelection = false;
            this.orderslv.Location = new System.Drawing.Point(522, 47);
            this.orderslv.Name = "orderslv";
            this.orderslv.Size = new System.Drawing.Size(336, 260);
            this.orderslv.TabIndex = 39;
            this.orderslv.UseCompatibleStateImageBehavior = false;
            this.orderslv.View = System.Windows.Forms.View.Details;
            this.orderslv.Visible = false;
            // 
            // gerecht
            // 
            this.gerecht.Text = "Gerecht";
            this.gerecht.Width = 257;
            // 
            // aantal
            // 
            this.aantal.Text = "Aantal";
            // 
            // consumptieLabel
            // 
            this.consumptieLabel.AutoSize = true;
            this.consumptieLabel.Font = new System.Drawing.Font("Segoe UI", 8F, System.Drawing.FontStyle.Bold);
            this.consumptieLabel.ForeColor = System.Drawing.Color.White;
            this.consumptieLabel.Location = new System.Drawing.Point(471, 349);
            this.consumptieLabel.Name = "consumptieLabel";
            this.consumptieLabel.Size = new System.Drawing.Size(0, 13);
            this.consumptieLabel.TabIndex = 38;
            // 
            // ConsumptieDD
            // 
            this.ConsumptieDD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ConsumptieDD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.ConsumptieDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ConsumptieDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.ConsumptieDD.ForeColor = System.Drawing.Color.White;
            this.ConsumptieDD.FormattingEnabled = true;
            this.ConsumptieDD.Location = new System.Drawing.Point(198, 165);
            this.ConsumptieDD.Name = "ConsumptieDD";
            this.ConsumptieDD.Size = new System.Drawing.Size(184, 29);
            this.ConsumptieDD.TabIndex = 37;
            this.ConsumptieDD.SelectedIndexChanged += new System.EventHandler(this.ConsumptieDD_SelectedIndexChanged);
            // 
            // minBtn
            // 
            this.minBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.minBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.minBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.minBtn.ForeColor = System.Drawing.Color.White;
            this.minBtn.Location = new System.Drawing.Point(198, 227);
            this.minBtn.Name = "minBtn";
            this.minBtn.Size = new System.Drawing.Size(42, 29);
            this.minBtn.TabIndex = 35;
            this.minBtn.Text = "-";
            this.minBtn.UseVisualStyleBackColor = false;
            this.minBtn.Click += new System.EventHandler(this.minBtn_Click);
            // 
            // plusBtn
            // 
            this.plusBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.plusBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.plusBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.plusBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.plusBtn.ForeColor = System.Drawing.Color.White;
            this.plusBtn.Location = new System.Drawing.Point(397, 227);
            this.plusBtn.Name = "plusBtn";
            this.plusBtn.Size = new System.Drawing.Size(42, 29);
            this.plusBtn.TabIndex = 36;
            this.plusBtn.Text = "+";
            this.plusBtn.UseVisualStyleBackColor = false;
            this.plusBtn.Click += new System.EventHandler(this.plusBtn_Click);
            // 
            // OrderAddBtn
            // 
            this.OrderAddBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderAddBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderAddBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderAddBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderAddBtn.ForeColor = System.Drawing.Color.White;
            this.OrderAddBtn.Location = new System.Drawing.Point(198, 428);
            this.OrderAddBtn.Name = "OrderAddBtn";
            this.OrderAddBtn.Size = new System.Drawing.Size(245, 38);
            this.OrderAddBtn.TabIndex = 19;
            this.OrderAddBtn.Text = "TOEVOEGEN";
            this.OrderAddBtn.UseVisualStyleBackColor = false;
            this.OrderAddBtn.Click += new System.EventHandler(this.OrderAddBtn_Click);
            // 
            // opmerkingBox
            // 
            this.opmerkingBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.opmerkingBox.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.opmerkingBox.ForeColor = System.Drawing.Color.White;
            this.opmerkingBox.Location = new System.Drawing.Point(198, 280);
            this.opmerkingBox.Multiline = true;
            this.opmerkingBox.Name = "opmerkingBox";
            this.opmerkingBox.Size = new System.Drawing.Size(241, 110);
            this.opmerkingBox.TabIndex = 9;
            // 
            // opmerkinglbl
            // 
            this.opmerkinglbl.AutoSize = true;
            this.opmerkinglbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.opmerkinglbl.ForeColor = System.Drawing.Color.White;
            this.opmerkinglbl.Location = new System.Drawing.Point(32, 283);
            this.opmerkinglbl.Name = "opmerkinglbl";
            this.opmerkinglbl.Size = new System.Drawing.Size(105, 21);
            this.opmerkinglbl.TabIndex = 8;
            this.opmerkinglbl.Text = "OPMERKING";
            // 
            // amountOrderItem
            // 
            this.amountOrderItem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.amountOrderItem.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.amountOrderItem.ForeColor = System.Drawing.Color.White;
            this.amountOrderItem.Location = new System.Drawing.Point(259, 226);
            this.amountOrderItem.Name = "amountOrderItem";
            this.amountOrderItem.Size = new System.Drawing.Size(123, 29);
            this.amountOrderItem.TabIndex = 7;
            // 
            // aantalllbl
            // 
            this.aantalllbl.AutoSize = true;
            this.aantalllbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.aantalllbl.ForeColor = System.Drawing.Color.White;
            this.aantalllbl.Location = new System.Drawing.Point(32, 226);
            this.aantalllbl.Name = "aantalllbl";
            this.aantalllbl.Size = new System.Drawing.Size(72, 21);
            this.aantalllbl.TabIndex = 6;
            this.aantalllbl.Text = "AANTAL";
            // 
            // Consumptielbl
            // 
            this.Consumptielbl.AutoSize = true;
            this.Consumptielbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.Consumptielbl.ForeColor = System.Drawing.Color.White;
            this.Consumptielbl.Location = new System.Drawing.Point(32, 167);
            this.Consumptielbl.Name = "Consumptielbl";
            this.Consumptielbl.Size = new System.Drawing.Size(114, 21);
            this.Consumptielbl.TabIndex = 4;
            this.Consumptielbl.Text = "CONSUMPTIE";
            // 
            // MenuDD
            // 
            this.MenuDD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.MenuDD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.MenuDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.MenuDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.MenuDD.ForeColor = System.Drawing.Color.White;
            this.MenuDD.FormattingEnabled = true;
            this.MenuDD.Location = new System.Drawing.Point(198, 103);
            this.MenuDD.Name = "MenuDD";
            this.MenuDD.Size = new System.Drawing.Size(241, 29);
            this.MenuDD.TabIndex = 3;
            this.MenuDD.SelectedIndexChanged += new System.EventHandler(this.MenuDD_SelectedIndexChanged);
            // 
            // Menulbl
            // 
            this.Menulbl.AutoSize = true;
            this.Menulbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.Menulbl.ForeColor = System.Drawing.Color.White;
            this.Menulbl.Location = new System.Drawing.Point(32, 105);
            this.Menulbl.Name = "Menulbl";
            this.Menulbl.Size = new System.Drawing.Size(59, 21);
            this.Menulbl.TabIndex = 2;
            this.Menulbl.Text = "MENU";
            // 
            // TafelDD
            // 
            this.TafelDD.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.TafelDD.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.TafelDD.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.TafelDD.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.TafelDD.ForeColor = System.Drawing.Color.White;
            this.TafelDD.FormattingEnabled = true;
            this.TafelDD.Location = new System.Drawing.Point(200, 46);
            this.TafelDD.Name = "TafelDD";
            this.TafelDD.Size = new System.Drawing.Size(239, 29);
            this.TafelDD.TabIndex = 1;
            // 
            // tafellbl
            // 
            this.tafellbl.AutoSize = true;
            this.tafellbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.tafellbl.ForeColor = System.Drawing.Color.White;
            this.tafellbl.Location = new System.Drawing.Point(32, 47);
            this.tafellbl.Name = "tafellbl";
            this.tafellbl.Size = new System.Drawing.Size(54, 21);
            this.tafellbl.TabIndex = 0;
            this.tafellbl.Text = "TAFEL";
            // 
            // BackToTablesBtn
            // 
            this.BackToTablesBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.BackToTablesBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.BackToTablesBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.BackToTablesBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.BackToTablesBtn.ForeColor = System.Drawing.Color.White;
            this.BackToTablesBtn.Location = new System.Drawing.Point(35, 431);
            this.BackToTablesBtn.Name = "BackToTablesBtn";
            this.BackToTablesBtn.Size = new System.Drawing.Size(216, 38);
            this.BackToTablesBtn.TabIndex = 20;
            this.BackToTablesBtn.Text = "TERUG NAAR TAFELS";
            this.BackToTablesBtn.UseVisualStyleBackColor = false;
            this.BackToTablesBtn.Click += new System.EventHandler(this.BackToTablesBtn_Click);
            // 
            // ChangeAmount_pnl
            // 
            this.ChangeAmount_pnl.Controls.Add(this.plusAantalBtn);
            this.ChangeAmount_pnl.Controls.Add(this.minAantalBtn);
            this.ChangeAmount_pnl.Controls.Add(this.ChangeAcceptBtn);
            this.ChangeAmount_pnl.Controls.Add(this.AmountBox);
            this.ChangeAmount_pnl.Controls.Add(this.Aantallbl);
            this.ChangeAmount_pnl.Controls.Add(this.orderItemlbl);
            this.ChangeAmount_pnl.Controls.Add(this.orderIDlbl);
            this.ChangeAmount_pnl.Location = new System.Drawing.Point(325, 0);
            this.ChangeAmount_pnl.Name = "ChangeAmount_pnl";
            this.ChangeAmount_pnl.Size = new System.Drawing.Size(773, 491);
            this.ChangeAmount_pnl.TabIndex = 49;
            // 
            // plusAantalBtn
            // 
            this.plusAantalBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.plusAantalBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.plusAantalBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.plusAantalBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.plusAantalBtn.ForeColor = System.Drawing.Color.White;
            this.plusAantalBtn.Location = new System.Drawing.Point(361, 167);
            this.plusAantalBtn.Name = "plusAantalBtn";
            this.plusAantalBtn.Size = new System.Drawing.Size(42, 29);
            this.plusAantalBtn.TabIndex = 37;
            this.plusAantalBtn.Text = "+";
            this.plusAantalBtn.UseVisualStyleBackColor = false;
            this.plusAantalBtn.Click += new System.EventHandler(this.plusAantalBtn_Click);
            // 
            // minAantalBtn
            // 
            this.minAantalBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.minAantalBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.minAantalBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.minAantalBtn.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.minAantalBtn.ForeColor = System.Drawing.Color.White;
            this.minAantalBtn.Location = new System.Drawing.Point(156, 167);
            this.minAantalBtn.Name = "minAantalBtn";
            this.minAantalBtn.Size = new System.Drawing.Size(42, 29);
            this.minAantalBtn.TabIndex = 36;
            this.minAantalBtn.Text = "-";
            this.minAantalBtn.UseVisualStyleBackColor = false;
            this.minAantalBtn.Click += new System.EventHandler(this.minAantalBtn_Click);
            // 
            // ChangeAcceptBtn
            // 
            this.ChangeAcceptBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ChangeAcceptBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ChangeAcceptBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ChangeAcceptBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ChangeAcceptBtn.ForeColor = System.Drawing.Color.White;
            this.ChangeAcceptBtn.Location = new System.Drawing.Point(187, 234);
            this.ChangeAcceptBtn.Name = "ChangeAcceptBtn";
            this.ChangeAcceptBtn.Size = new System.Drawing.Size(216, 38);
            this.ChangeAcceptBtn.TabIndex = 19;
            this.ChangeAcceptBtn.Text = "BIJWERKEN";
            this.ChangeAcceptBtn.UseVisualStyleBackColor = false;
            this.ChangeAcceptBtn.Click += new System.EventHandler(this.ChangeAcceptBtn_Click);
            // 
            // AmountBox
            // 
            this.AmountBox.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AmountBox.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AmountBox.ForeColor = System.Drawing.Color.White;
            this.AmountBox.Location = new System.Drawing.Point(226, 167);
            this.AmountBox.Name = "AmountBox";
            this.AmountBox.Size = new System.Drawing.Size(112, 29);
            this.AmountBox.TabIndex = 3;
            // 
            // Aantallbl
            // 
            this.Aantallbl.AutoSize = true;
            this.Aantallbl.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.Aantallbl.ForeColor = System.Drawing.Color.White;
            this.Aantallbl.Location = new System.Drawing.Point(44, 167);
            this.Aantallbl.Name = "Aantallbl";
            this.Aantallbl.Size = new System.Drawing.Size(60, 21);
            this.Aantallbl.TabIndex = 2;
            this.Aantallbl.Text = "Aantal";
            // 
            // orderItemlbl
            // 
            this.orderItemlbl.AutoSize = true;
            this.orderItemlbl.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.orderItemlbl.ForeColor = System.Drawing.Color.White;
            this.orderItemlbl.Location = new System.Drawing.Point(297, 103);
            this.orderItemlbl.Name = "orderItemlbl";
            this.orderItemlbl.Size = new System.Drawing.Size(109, 25);
            this.orderItemlbl.TabIndex = 1;
            this.orderItemlbl.Text = "Order Item";
            // 
            // orderIDlbl
            // 
            this.orderIDlbl.AutoSize = true;
            this.orderIDlbl.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.orderIDlbl.ForeColor = System.Drawing.Color.White;
            this.orderIDlbl.Location = new System.Drawing.Point(44, 103);
            this.orderIDlbl.Name = "orderIDlbl";
            this.orderIDlbl.Size = new System.Drawing.Size(89, 25);
            this.orderIDlbl.TabIndex = 0;
            this.orderIDlbl.Text = "Order ID";
            // 
            // AllOrdersBtn2
            // 
            this.AllOrdersBtn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllOrdersBtn2.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AllOrdersBtn2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AllOrdersBtn2.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AllOrdersBtn2.ForeColor = System.Drawing.Color.White;
            this.AllOrdersBtn2.Location = new System.Drawing.Point(35, 147);
            this.AllOrdersBtn2.Name = "AllOrdersBtn2";
            this.AllOrdersBtn2.Size = new System.Drawing.Size(216, 38);
            this.AllOrdersBtn2.TabIndex = 19;
            this.AllOrdersBtn2.Text = "ALLE BESTELLINGEN";
            this.AllOrdersBtn2.UseVisualStyleBackColor = false;
            this.AllOrdersBtn2.Click += new System.EventHandler(this.AllOrdersBtn2_Click);
            // 
            // AddBtn
            // 
            this.AddBtn.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddBtn.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.AddBtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.AddBtn.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.AddBtn.ForeColor = System.Drawing.Color.White;
            this.AddBtn.Location = new System.Drawing.Point(35, 103);
            this.AddBtn.Name = "AddBtn";
            this.AddBtn.Size = new System.Drawing.Size(216, 38);
            this.AddBtn.TabIndex = 18;
            this.AddBtn.Text = "BESTELLING TOEVOEGEN";
            this.AddBtn.UseVisualStyleBackColor = false;
            this.AddBtn.Click += new System.EventHandler(this.AddBtn_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox2.Image = global::ChapooUI.Properties.Resources.output_onlinepngtools__8_;
            this.pictureBox2.Location = new System.Drawing.Point(35, 22);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(65, 56);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 13;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox1.Image = global::ChapooUI.Properties.Resources.png_logo_white;
            this.pictureBox1.Location = new System.Drawing.Point(13, 9);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(85, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // Table1_Title
            // 
            this.Table1_Title.AutoSize = true;
            this.Table1_Title.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Table1_Title.ForeColor = System.Drawing.Color.White;
            this.Table1_Title.Location = new System.Drawing.Point(23, 15);
            this.Table1_Title.Name = "Table1_Title";
            this.Table1_Title.Size = new System.Drawing.Size(80, 21);
            this.Table1_Title.TabIndex = 14;
            this.Table1_Title.Text = "TAFEL 1 | ";
            // 
            // OrderBtn1
            // 
            this.OrderBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.OrderBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.OrderBtn1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.OrderBtn1.ForeColor = System.Drawing.Color.White;
            this.OrderBtn1.Location = new System.Drawing.Point(27, 51);
            this.OrderBtn1.Name = "OrderBtn1";
            this.OrderBtn1.Size = new System.Drawing.Size(216, 38);
            this.OrderBtn1.TabIndex = 15;
            this.OrderBtn1.Text = "BESTELLING";
            this.OrderBtn1.UseVisualStyleBackColor = false;
            this.OrderBtn1.Click += new System.EventHandler(this.OrderBtn1_Click);
            // 
            // ReservationBtn1
            // 
            this.ReservationBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.ReservationBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ReservationBtn1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.ReservationBtn1.ForeColor = System.Drawing.Color.White;
            this.ReservationBtn1.Location = new System.Drawing.Point(27, 95);
            this.ReservationBtn1.Name = "ReservationBtn1";
            this.ReservationBtn1.Size = new System.Drawing.Size(216, 38);
            this.ReservationBtn1.TabIndex = 16;
            this.ReservationBtn1.Text = "RESERVATIE";
            this.ReservationBtn1.UseVisualStyleBackColor = false;
            this.ReservationBtn1.Click += new System.EventHandler(this.ReservationBtn1_Click);
            // 
            // PayBtn1
            // 
            this.PayBtn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn1.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.PayBtn1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.PayBtn1.Font = new System.Drawing.Font("Segoe UI", 12F);
            this.PayBtn1.ForeColor = System.Drawing.Color.White;
            this.PayBtn1.Location = new System.Drawing.Point(27, 139);
            this.PayBtn1.Name = "PayBtn1";
            this.PayBtn1.Size = new System.Drawing.Size(216, 38);
            this.PayBtn1.TabIndex = 17;
            this.PayBtn1.Text = "AFREKENEN";
            this.PayBtn1.UseVisualStyleBackColor = false;
            this.PayBtn1.Click += new System.EventHandler(this.PayBtn1_Click_1);
            // 
            // Table1_pnl
            // 
            this.Table1_pnl.Controls.Add(this.lbl_tf_1);
            this.Table1_pnl.Controls.Add(this.lbl_w_1);
            this.Table1_pnl.Controls.Add(this.PayBtn1);
            this.Table1_pnl.Controls.Add(this.ReservationBtn1);
            this.Table1_pnl.Controls.Add(this.OrderBtn1);
            this.Table1_pnl.Controls.Add(this.Table1_Title);
            this.Table1_pnl.Location = new System.Drawing.Point(13, 82);
            this.Table1_pnl.Name = "Table1_pnl";
            this.Table1_pnl.Size = new System.Drawing.Size(266, 202);
            this.Table1_pnl.TabIndex = 13;
            // 
            // lbl_tf_1
            // 
            this.lbl_tf_1.AutoSize = true;
            this.lbl_tf_1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold);
            this.lbl_tf_1.ForeColor = System.Drawing.Color.White;
            this.lbl_tf_1.Location = new System.Drawing.Point(102, 15);
            this.lbl_tf_1.Name = "lbl_tf_1";
            this.lbl_tf_1.Size = new System.Drawing.Size(62, 21);
            this.lbl_tf_1.TabIndex = 23;
            this.lbl_tf_1.Text = "asdasd";
            // 
            // lbl_w_1
            // 
            this.lbl_w_1.AutoSize = true;
            this.lbl_w_1.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_w_1.ForeColor = System.Drawing.Color.White;
            this.lbl_w_1.Location = new System.Drawing.Point(28, 177);
            this.lbl_w_1.Name = "lbl_w_1";
            this.lbl_w_1.Size = new System.Drawing.Size(161, 21);
            this.lbl_w_1.TabIndex = 22;
            this.lbl_w_1.Text = "Geen lopende order";
            // 
            // pnl_Afrekenen
            // 
            this.pnl_Afrekenen.Controls.Add(this.txtbox_betaaldBedrag);
            this.pnl_Afrekenen.Controls.Add(this.lbl_betaaldBedrag);
            this.pnl_Afrekenen.Controls.Add(this.label7);
            this.pnl_Afrekenen.Controls.Add(this.cmbBox_betaalmethode);
            this.pnl_Afrekenen.Controls.Add(this.listview_productenAfrekenen);
            this.pnl_Afrekenen.Controls.Add(this.lbl_afrekenen);
            this.pnl_Afrekenen.Controls.Add(this.txtbox_fooiBedrag);
            this.pnl_Afrekenen.Controls.Add(this.lbl_orderIDAfrekenen);
            this.pnl_Afrekenen.Controls.Add(this.lbl_AfrekenTafel);
            this.pnl_Afrekenen.Controls.Add(this.lbl_fooi);
            this.pnl_Afrekenen.Controls.Add(this.lbl_btw);
            this.pnl_Afrekenen.Controls.Add(this.lbl_overzichtBedrag);
            this.pnl_Afrekenen.Controls.Add(this.lbl_totaalOverzicht);
            this.pnl_Afrekenen.Controls.Add(this.lbl_btwBedrag);
            this.pnl_Afrekenen.Controls.Add(this.btn_terugTafels);
            this.pnl_Afrekenen.Location = new System.Drawing.Point(0, 0);
            this.pnl_Afrekenen.Margin = new System.Windows.Forms.Padding(2);
            this.pnl_Afrekenen.Name = "pnl_Afrekenen";
            this.pnl_Afrekenen.Size = new System.Drawing.Size(1405, 608);
            this.pnl_Afrekenen.TabIndex = 30;
            // 
            // txtbox_betaaldBedrag
            // 
            this.txtbox_betaaldBedrag.Location = new System.Drawing.Point(676, 464);
            this.txtbox_betaaldBedrag.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_betaaldBedrag.Multiline = true;
            this.txtbox_betaaldBedrag.Name = "txtbox_betaaldBedrag";
            this.txtbox_betaaldBedrag.Size = new System.Drawing.Size(151, 24);
            this.txtbox_betaaldBedrag.TabIndex = 46;
            // 
            // lbl_betaaldBedrag
            // 
            this.lbl_betaaldBedrag.AutoSize = true;
            this.lbl_betaaldBedrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_betaaldBedrag.ForeColor = System.Drawing.Color.White;
            this.lbl_betaaldBedrag.Location = new System.Drawing.Point(417, 464);
            this.lbl_betaaldBedrag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_betaaldBedrag.Name = "lbl_betaaldBedrag";
            this.lbl_betaaldBedrag.Size = new System.Drawing.Size(152, 17);
            this.lbl_betaaldBedrag.TabIndex = 45;
            this.lbl_betaaldBedrag.Text = "BETAALD BEDRAG:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(417, 418);
            this.label7.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(148, 17);
            this.label7.TabIndex = 44;
            this.label7.Text = "BETAALMETHODE:";
            // 
            // cmbBox_betaalmethode
            // 
            this.cmbBox_betaalmethode.FormattingEnabled = true;
            this.cmbBox_betaalmethode.Location = new System.Drawing.Point(675, 416);
            this.cmbBox_betaalmethode.Margin = new System.Windows.Forms.Padding(2);
            this.cmbBox_betaalmethode.Name = "cmbBox_betaalmethode";
            this.cmbBox_betaalmethode.Size = new System.Drawing.Size(152, 21);
            this.cmbBox_betaalmethode.TabIndex = 41;
            // 
            // listview_productenAfrekenen
            // 
            this.listview_productenAfrekenen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(46)))), ((int)(((byte)(63)))));
            this.listview_productenAfrekenen.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.AfrekenID,
            this.AfrekenProduct,
            this.AfrekenAantal});
            this.listview_productenAfrekenen.ForeColor = System.Drawing.Color.White;
            this.listview_productenAfrekenen.HideSelection = false;
            this.listview_productenAfrekenen.Location = new System.Drawing.Point(964, 202);
            this.listview_productenAfrekenen.Margin = new System.Windows.Forms.Padding(2);
            this.listview_productenAfrekenen.Name = "listview_productenAfrekenen";
            this.listview_productenAfrekenen.Size = new System.Drawing.Size(387, 304);
            this.listview_productenAfrekenen.TabIndex = 39;
            this.listview_productenAfrekenen.UseCompatibleStateImageBehavior = false;
            this.listview_productenAfrekenen.View = System.Windows.Forms.View.Details;
            // 
            // AfrekenID
            // 
            this.AfrekenID.Text = "ID";
            this.AfrekenID.Width = 91;
            // 
            // AfrekenProduct
            // 
            this.AfrekenProduct.Text = "Product";
            this.AfrekenProduct.Width = 114;
            // 
            // AfrekenAantal
            // 
            this.AfrekenAantal.Text = "Aantal";
            this.AfrekenAantal.Width = 69;
            // 
            // lbl_afrekenen
            // 
            this.lbl_afrekenen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.lbl_afrekenen.FlatAppearance.BorderSize = 0;
            this.lbl_afrekenen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lbl_afrekenen.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_afrekenen.ForeColor = System.Drawing.Color.White;
            this.lbl_afrekenen.Location = new System.Drawing.Point(1201, 538);
            this.lbl_afrekenen.Margin = new System.Windows.Forms.Padding(2);
            this.lbl_afrekenen.Name = "lbl_afrekenen";
            this.lbl_afrekenen.Size = new System.Drawing.Size(149, 27);
            this.lbl_afrekenen.TabIndex = 34;
            this.lbl_afrekenen.Text = "AFREKENEN";
            this.lbl_afrekenen.UseVisualStyleBackColor = false;
            // 
            // txtbox_fooiBedrag
            // 
            this.txtbox_fooiBedrag.Location = new System.Drawing.Point(676, 365);
            this.txtbox_fooiBedrag.Margin = new System.Windows.Forms.Padding(2);
            this.txtbox_fooiBedrag.Multiline = true;
            this.txtbox_fooiBedrag.Name = "txtbox_fooiBedrag";
            this.txtbox_fooiBedrag.Size = new System.Drawing.Size(151, 24);
            this.txtbox_fooiBedrag.TabIndex = 32;
            // 
            // lbl_orderIDAfrekenen
            // 
            this.lbl_orderIDAfrekenen.AutoSize = true;
            this.lbl_orderIDAfrekenen.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_orderIDAfrekenen.ForeColor = System.Drawing.Color.White;
            this.lbl_orderIDAfrekenen.Location = new System.Drawing.Point(961, 153);
            this.lbl_orderIDAfrekenen.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_orderIDAfrekenen.Name = "lbl_orderIDAfrekenen";
            this.lbl_orderIDAfrekenen.Size = new System.Drawing.Size(20, 17);
            this.lbl_orderIDAfrekenen.TabIndex = 42;
            this.lbl_orderIDAfrekenen.Text = "--";
            // 
            // lbl_AfrekenTafel
            // 
            this.lbl_AfrekenTafel.AutoSize = true;
            this.lbl_AfrekenTafel.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_AfrekenTafel.ForeColor = System.Drawing.Color.White;
            this.lbl_AfrekenTafel.Location = new System.Drawing.Point(418, 101);
            this.lbl_AfrekenTafel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_AfrekenTafel.Name = "lbl_AfrekenTafel";
            this.lbl_AfrekenTafel.Size = new System.Drawing.Size(20, 17);
            this.lbl_AfrekenTafel.TabIndex = 29;
            this.lbl_AfrekenTafel.Text = "--";
            // 
            // lbl_fooi
            // 
            this.lbl_fooi.AutoSize = true;
            this.lbl_fooi.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_fooi.ForeColor = System.Drawing.Color.White;
            this.lbl_fooi.Location = new System.Drawing.Point(417, 369);
            this.lbl_fooi.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_fooi.Name = "lbl_fooi";
            this.lbl_fooi.Size = new System.Drawing.Size(50, 17);
            this.lbl_fooi.TabIndex = 28;
            this.lbl_fooi.Text = "FOOI:";
            // 
            // lbl_btw
            // 
            this.lbl_btw.AutoSize = true;
            this.lbl_btw.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_btw.ForeColor = System.Drawing.Color.White;
            this.lbl_btw.Location = new System.Drawing.Point(417, 244);
            this.lbl_btw.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_btw.Name = "lbl_btw";
            this.lbl_btw.Size = new System.Drawing.Size(47, 17);
            this.lbl_btw.TabIndex = 26;
            this.lbl_btw.Text = "BTW:";
            // 
            // lbl_overzichtBedrag
            // 
            this.lbl_overzichtBedrag.AutoSize = true;
            this.lbl_overzichtBedrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_overzichtBedrag.ForeColor = System.Drawing.Color.White;
            this.lbl_overzichtBedrag.Location = new System.Drawing.Point(672, 202);
            this.lbl_overzichtBedrag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_overzichtBedrag.Name = "lbl_overzichtBedrag";
            this.lbl_overzichtBedrag.Size = new System.Drawing.Size(34, 20);
            this.lbl_overzichtBedrag.TabIndex = 25;
            this.lbl_overzichtBedrag.Text = "€ 0";
            // 
            // lbl_totaalOverzicht
            // 
            this.lbl_totaalOverzicht.AutoSize = true;
            this.lbl_totaalOverzicht.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_totaalOverzicht.ForeColor = System.Drawing.Color.White;
            this.lbl_totaalOverzicht.Location = new System.Drawing.Point(417, 202);
            this.lbl_totaalOverzicht.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_totaalOverzicht.Name = "lbl_totaalOverzicht";
            this.lbl_totaalOverzicht.Size = new System.Drawing.Size(167, 17);
            this.lbl_totaalOverzicht.TabIndex = 24;
            this.lbl_totaalOverzicht.Text = "TOTAAL OVERZICHT:";
            // 
            // lbl_btwBedrag
            // 
            this.lbl_btwBedrag.AutoSize = true;
            this.lbl_btwBedrag.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_btwBedrag.ForeColor = System.Drawing.Color.White;
            this.lbl_btwBedrag.Location = new System.Drawing.Point(672, 242);
            this.lbl_btwBedrag.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lbl_btwBedrag.Name = "lbl_btwBedrag";
            this.lbl_btwBedrag.Size = new System.Drawing.Size(34, 20);
            this.lbl_btwBedrag.TabIndex = 23;
            this.lbl_btwBedrag.Text = "€ 0";
            // 
            // btn_terugTafels
            // 
            this.btn_terugTafels.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.btn_terugTafels.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(70)))), ((int)(((byte)(93)))));
            this.btn_terugTafels.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_terugTafels.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_terugTafels.ForeColor = System.Drawing.Color.White;
            this.btn_terugTafels.Location = new System.Drawing.Point(66, 202);
            this.btn_terugTafels.Name = "btn_terugTafels";
            this.btn_terugTafels.Size = new System.Drawing.Size(216, 38);
            this.btn_terugTafels.TabIndex = 21;
            this.btn_terugTafels.Text = "TERUG NAAR TAFELS";
            this.btn_terugTafels.UseVisualStyleBackColor = false;
            // 
            // BedieningForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(38)))), ((int)(((byte)(46)))), ((int)(((byte)(63)))));
            this.ClientSize = new System.Drawing.Size(1443, 605);
            this.Controls.Add(this.Order_pnl);
            this.Controls.Add(this.AllreservationsBtn);
            this.Controls.Add(this.AllOrdersBtn);
            this.Controls.Add(this.Table10_pnl);
            this.Controls.Add(this.Table9_pnl);
            this.Controls.Add(this.Table5_pnl);
            this.Controls.Add(this.Table8_pnl);
            this.Controls.Add(this.Table4_pnl);
            this.Controls.Add(this.Table7_pnl);
            this.Controls.Add(this.Table3_pnl);
            this.Controls.Add(this.Table2_pnl);
            this.Controls.Add(this.Table6_pnl);
            this.Controls.Add(this.Table1_pnl);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.LogOffLink);
            this.Controls.Add(this.Chapoo_title);
            this.Controls.Add(this.pnl_Afrekenen);
            this.Name = "BedieningForm";
            this.Text = "BedieningForm";
            this.Table6_pnl.ResumeLayout(false);
            this.Table6_pnl.PerformLayout();
            this.Table7_pnl.ResumeLayout(false);
            this.Table7_pnl.PerformLayout();
            this.Table2_pnl.ResumeLayout(false);
            this.Table2_pnl.PerformLayout();
            this.Table8_pnl.ResumeLayout(false);
            this.Table8_pnl.PerformLayout();
            this.Table3_pnl.ResumeLayout(false);
            this.Table3_pnl.PerformLayout();
            this.Table9_pnl.ResumeLayout(false);
            this.Table9_pnl.PerformLayout();
            this.Table4_pnl.ResumeLayout(false);
            this.Table4_pnl.PerformLayout();
            this.Table10_pnl.ResumeLayout(false);
            this.Table10_pnl.PerformLayout();
            this.Table5_pnl.ResumeLayout(false);
            this.Table5_pnl.PerformLayout();
            this.Order_pnl.ResumeLayout(false);
            this.AllOrders_pnl.ResumeLayout(false);
            this.AllOrders_pnl.PerformLayout();
            this.ChangeRes_pnl.ResumeLayout(false);
            this.ChangeRes_pnl.PerformLayout();
            this.Res_pnl.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.AddRes_pnl.ResumeLayout(false);
            this.AddRes_pnl.PerformLayout();
            this.AddOrder_pnl.ResumeLayout(false);
            this.AddOrder_pnl.PerformLayout();
            this.ChangeAmount_pnl.ResumeLayout(false);
            this.ChangeAmount_pnl.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.Table1_pnl.ResumeLayout(false);
            this.Table1_pnl.PerformLayout();
            this.pnl_Afrekenen.ResumeLayout(false);
            this.pnl_Afrekenen.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Chapoo_title;
        private System.Windows.Forms.Label LogOffLink;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel Table6_pnl;
        private System.Windows.Forms.Button PayBtn6;
        private System.Windows.Forms.Button ReservationBtn6;
        private System.Windows.Forms.Button OrderBtn6;
        private System.Windows.Forms.Label Table6_Title;
        private System.Windows.Forms.Panel Table7_pnl;
        private System.Windows.Forms.Button PayBtn7;
        private System.Windows.Forms.Button ReservationBtn7;
        private System.Windows.Forms.Button OrderBtn7;
        private System.Windows.Forms.Label Table7_Title;
        private System.Windows.Forms.Panel Table2_pnl;
        private System.Windows.Forms.Button PayBtn2;
        private System.Windows.Forms.Button ReservationBtn2;
        private System.Windows.Forms.Button OrderBtn2;
        private System.Windows.Forms.Label Table2_Title;
        private System.Windows.Forms.Panel Table8_pnl;
        private System.Windows.Forms.Button PayBtn8;
        private System.Windows.Forms.Button Reser8vationBtn;
        private System.Windows.Forms.Button OrderBtn8;
        private System.Windows.Forms.Label Table8_Title;
        private System.Windows.Forms.Panel Table3_pnl;
        private System.Windows.Forms.Button PayBtn3;
        private System.Windows.Forms.Button ReservationBtn3;
        private System.Windows.Forms.Button OrderBtn3;
        private System.Windows.Forms.Label Table3_Title;
        private System.Windows.Forms.Panel Table9_pnl;
        private System.Windows.Forms.Button PayBtn9;
        private System.Windows.Forms.Button ReservationBtn9;
        private System.Windows.Forms.Button OrderBtn9;
        private System.Windows.Forms.Label Table9_Title;
        private System.Windows.Forms.Panel Table4_pnl;
        private System.Windows.Forms.Button PayBtn4;
        private System.Windows.Forms.Button ResservationBtn4;
        private System.Windows.Forms.Button OrderBtn4;
        private System.Windows.Forms.Label Table4_tiitle;
        private System.Windows.Forms.Panel Table10_pnl;
        private System.Windows.Forms.Button PayBtn10;
        private System.Windows.Forms.Button ReservationBtn10;
        private System.Windows.Forms.Button OrderBtn10;
        private System.Windows.Forms.Label Table10_Title;
        private System.Windows.Forms.Panel Table5_pnl;
        private System.Windows.Forms.Button PayBtn5;
        private System.Windows.Forms.Button ReservationBtn5;
        private System.Windows.Forms.Button OrderBtn5;
        private System.Windows.Forms.Label Table5_Title;
        private System.Windows.Forms.Button AllOrdersBtn;
        private System.Windows.Forms.Button AllreservationsBtn;
        private System.Windows.Forms.Panel Order_pnl;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Button BackToTablesBtn;
        private System.Windows.Forms.Button AllOrdersBtn2;
        private System.Windows.Forms.Button AddBtn;
        private System.Windows.Forms.Panel AllOrders_pnl;
        private System.Windows.Forms.ListView AllOrderslv;
        private System.Windows.Forms.ColumnHeader order_id;
        private System.Windows.Forms.Button DeleteOrderItemBtn;
        private System.Windows.Forms.Button DeleteOrderBtn;
        private System.Windows.Forms.Button ChangeBtn;
        private System.Windows.Forms.Panel AddOrder_pnl;
        private System.Windows.Forms.Button minBtn;
        private System.Windows.Forms.Button plusBtn;
        private System.Windows.Forms.Button OrderAddBtn;
        private System.Windows.Forms.TextBox opmerkingBox;
        private System.Windows.Forms.Label opmerkinglbl;
        private System.Windows.Forms.TextBox amountOrderItem;
        private System.Windows.Forms.Label aantalllbl;
        private System.Windows.Forms.Label Consumptielbl;
        private System.Windows.Forms.ComboBox MenuDD;
        private System.Windows.Forms.Label Menulbl;
        private System.Windows.Forms.ComboBox TafelDD;
        private System.Windows.Forms.Label tafellbl;
        private System.Windows.Forms.ComboBox ConsumptieDD;
        private System.Windows.Forms.Label consumptieLabel;
        private System.Windows.Forms.ListView orderslv;
        private System.Windows.Forms.ColumnHeader gerecht;
        private System.Windows.Forms.ColumnHeader aantal;
        private System.Windows.Forms.Button AllResBtn;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Button AddResBtn;
        private System.Windows.Forms.Panel Res_pnl;
        private System.Windows.Forms.Button ChangeResBtn;
        private System.Windows.Forms.Button DeleteResBtn;
        private System.Windows.Forms.ListView Reservationlv;
        private System.Windows.Forms.ColumnHeader reservationId;
        private System.Windows.Forms.ColumnHeader tableId;
        private System.Windows.Forms.ColumnHeader reservationName;
        private System.Windows.Forms.ColumnHeader reservationTel;
        private System.Windows.Forms.ColumnHeader reservationEmail;
        private System.Windows.Forms.ColumnHeader reservationComment;
        private System.Windows.Forms.ColumnHeader reservationDate;
        private System.Windows.Forms.Panel ChangeRes_pnl;
        private System.Windows.Forms.TextBox aamBox;
        private System.Windows.Forms.Label naamLbl;
        private System.Windows.Forms.Button ChangeResAcceptBtn;
        private System.Windows.Forms.TextBox aantekeningBox;
        private System.Windows.Forms.Label aantekeninglbl;
        private System.Windows.Forms.TextBox datumBox;
        private System.Windows.Forms.TextBox emailBox;
        private System.Windows.Forms.TextBox telBox;
        private System.Windows.Forms.Label datumLbl;
        private System.Windows.Forms.Label emailLbl;
        private System.Windows.Forms.Label telnrLbl;
        private System.Windows.Forms.Label ResTafellbl;
        private System.Windows.Forms.Panel AddRes_pnl;
        private System.Windows.Forms.TextBox AddNaamDD;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button BevestigResBtn;
        private System.Windows.Forms.TextBox AddOpmerking;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox AddDatum;
        private System.Windows.Forms.TextBox AddEmail;
        private System.Windows.Forms.TextBox Addtel;
        private System.Windows.Forms.ComboBox AddTafelDD;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox TafelResDD;
        private System.Windows.Forms.ComboBox ChooseTableDD;
        private System.Windows.Forms.Label ChooseTablelbl;
        private System.Windows.Forms.ColumnHeader orderTableId;
        private System.Windows.Forms.ColumnHeader itemName_;
        private System.Windows.Forms.ColumnHeader aantal1;
        private System.Windows.Forms.ColumnHeader orderItemStatus_;
        private System.Windows.Forms.Panel ChangeAmount_pnl;
        private System.Windows.Forms.Button plusAantalBtn;
        private System.Windows.Forms.Button minAantalBtn;
        private System.Windows.Forms.Button ChangeAcceptBtn;
        private System.Windows.Forms.TextBox AmountBox;
        private System.Windows.Forms.Label Aantallbl;
        private System.Windows.Forms.Label orderItemlbl;
        private System.Windows.Forms.Label orderIDlbl;
        private System.Windows.Forms.Label Table1_Title;
        private System.Windows.Forms.Button OrderBtn1;
        private System.Windows.Forms.Button ReservationBtn1;
        private System.Windows.Forms.Button PayBtn1;
        private System.Windows.Forms.Panel Table1_pnl;
        private System.Windows.Forms.Label lbl_w_6;
        private System.Windows.Forms.Label lbl_w_7;
        private System.Windows.Forms.Label lbl_w_2;
        private System.Windows.Forms.Label lbl_w_8;
        private System.Windows.Forms.Label lbl_w_3;
        private System.Windows.Forms.Label lbl_w_9;
        private System.Windows.Forms.Label lbl_w_4;
        private System.Windows.Forms.Label lbl_w_5;
        private System.Windows.Forms.Label lbl_w_1;
        private System.Windows.Forms.Label lbl_w_10;
        private System.Windows.Forms.Label lbl_tf_2;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label lbl_tf_3;
        private System.Windows.Forms.Label lbl_tf_4;
        private System.Windows.Forms.Label lbl_tf_1;
        private System.Windows.Forms.Label lbl_tf_5;
        private System.Windows.Forms.Label lbl_tf_6;
        private System.Windows.Forms.Label lbl_tf_7;
        private System.Windows.Forms.Label lbl_tf_8;
        private System.Windows.Forms.Label lbl_tf_9;
        private System.Windows.Forms.Label lbl_tf_10;
        private System.Windows.Forms.Panel pnl_Afrekenen;
        private System.Windows.Forms.TextBox txtbox_betaaldBedrag;
        private System.Windows.Forms.Label lbl_betaaldBedrag;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbBox_betaalmethode;
        private System.Windows.Forms.ListView listview_productenAfrekenen;
        private System.Windows.Forms.ColumnHeader AfrekenID;
        private System.Windows.Forms.ColumnHeader AfrekenProduct;
        private System.Windows.Forms.ColumnHeader AfrekenAantal;
        private System.Windows.Forms.Button lbl_afrekenen;
        private System.Windows.Forms.TextBox txtbox_fooiBedrag;
        private System.Windows.Forms.Label lbl_orderIDAfrekenen;
        private System.Windows.Forms.Label lbl_AfrekenTafel;
        private System.Windows.Forms.Label lbl_fooi;
        private System.Windows.Forms.Label lbl_btw;
        private System.Windows.Forms.Label lbl_overzichtBedrag;
        private System.Windows.Forms.Label lbl_totaalOverzicht;
        private System.Windows.Forms.Label lbl_btwBedrag;
        private System.Windows.Forms.Button btn_terugTafels;
    }
}