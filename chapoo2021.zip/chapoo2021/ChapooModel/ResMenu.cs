﻿namespace ChapooModel
{
    public class ResMenu
    {
        public int menuItemId;
        public int menuId;
        public decimal price;
        public int stock;
        public bool alcoholl;
        public string itemName;

    }
    public class Lunch { public string itemName { get; set; } }
    public class Diner { public string itemName { get; set; } }
    public class Drankjes { public string itemName { get; set; } }
}
